# Momentum — AI Focus & Habit Companion

A production-structured Android app built with **Kotlin, Jetpack Compose, Material 3, Room, Hilt and WorkManager**, following Clean Architecture with MVI/MVVM presentation. Momentum unifies habits, tasks, goals, focus sessions, study planning, journaling and insights into one calm, fluid interface.

---

## Features

**Today (command centre)**
- Greeting header with animated daily-progress ring, current streak and focused minutes
- On-device **Momentum Coach** that generates a personalised tip from your live data
- Overdue tasks, today's habits (with quantity / time-based progress) and today's tasks
- Quick jump into a focus session

**Habits**
- Daily / weekly / custom-day schedules
- Boolean, quantity (e.g. 8 glasses) and time-based (minutes) tracking
- 7-day week strip with per-day completion, weekly counts, icon + colour picker, reminders
- Archive and delete

**Tasks**
- Priority, due dates, notes, estimated minutes, recurring-ready schema
- Grouped into Overdue / Today / Upcoming / No date / Completed with filters
- Animated completion

**Focus (Pomodoro)**
- Work / short break / long break modes with automatic 4-cycle long break
- Big animated progress ring, session logging to Room, completion notifications
- Live stats: sessions today, minutes focused, cycle position

**Goals**
- Categories (Student / Personal / Career / Health), target dates and progress tracking

**Student Mode**
- Subjects with exam dates, target hours and difficulty
- `StudyPlanner` distributes study minutes across the next 7 days by urgency × difficulty
- One tap turns the plan into concrete, dated tasks

**Insights**
- Canvas bar charts for weekly focus minutes and habit completion
- Streaks (current + longest), tasks completed, average journal mood
- Coach insights generated locally from your history

**Journal**
- Searchable entries with mood scoring (1–5)

**Settings**
- Profile, light/dark/system theme, Material You dynamic colour
- Focus/break durations, daily habit goal, reminders, daily digest, coach toggle
- Full JSON **export / import** via the Storage Access Framework

**System**
- Exact-alarm habit reminders (`AlarmManager`) with graceful fallback when permission is absent
- `WorkManager` daily digest via a Hilt-injected worker
- Boot receiver re-schedules all reminders after reboot

---

## Tech stack

| Layer | Choice |
|---|---|
| Language / UI | Kotlin 1.9.24, Jetpack Compose (BOM 2024.06), Material 3 |
| Architecture | Clean-ish layering, MVVM/MVI, unidirectional `StateFlow` |
| Persistence | Room 2.6.1 (8 entities, 8 DAOs), DataStore Preferences |
| DI | Hilt 2.51.1 + KSP |
| Background | WorkManager 2.9.0 (Hilt worker) + AlarmManager |
| Serialization | kotlinx.serialization (JSON backup) |
| Min / target SDK | 26 / 35 |

---

## Project structure

```
app/src/main/java/com/momentum/app/
├── MomentumApplication.kt        # @HiltAndroidApp, WorkManager config, channels
├── MainActivity.kt               # edge-to-edge Compose host
├── MainViewModel.kt              # theme + onboarding state
├── core/                         # Constants, DateUtils, Formatters
├── data/
│   ├── local/                    # Room entities, DAOs, database
│   ├── repository/               # 8 repositories (Flow-first)
│   └── backup/                   # BackupPayload + DataBackupManager (SAF)
├── domain/
│   ├── study/StudyPlanner.kt     # deterministic study scheduler
│   └── util/StreakCalculator.kt
├── di/DatabaseModule.kt
├── reminder/                     # NotificationHelper, ReminderScheduler,
│                                 # HabitAlarmReceiver, BootReceiver, DailyDigestWorker
└── ui/
    ├── theme/                    # Color, Type, Shape, Theme
    ├── components/               # MomentumCard, HabitRow, TaskRow, ProgressRing, …
    ├── navigation/               # Routes + bottom nav items
    ├── util/IconMapper.kt
    ├── MomentumApp.kt            # NavHost + adaptive bottom bar
    └── screens/                  # onboarding, today, habits, tasks, focus,
                                  # goals, insights, student, journal, settings
```

88 Kotlin files across 8 Room entities, 8 DAOs, 8 repositories, 10 feature screens and their view models.

---

## Getting started

1. **Open in Android Studio** (Ladybug or newer) — *File ▸ Open* and select this folder.
2. Wait for the first **Gradle sync** (it downloads Gradle 8.7 and the dependencies — a few minutes on first run).
3. Build the debug APK from the terminal:
   ```bash
   ./gradlew :app:assembleDebug        # macOS / Linux
   gradlew.bat :app:assembleDebug      # Windows
   ```
   …or just press the green **Run ▶** button in Android Studio.
4. Install on a device or emulator running **Android 8.0 (API 26)** or higher.

> The Gradle wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`) is included, so no local Gradle install is needed — Android Studio will download Gradle 8.7 automatically.

### Building without a computer (phone-only)

Android Studio needs a desktop OS. If you only have a phone, use the bundled
GitHub Actions workflow to build the APK in the cloud:

1. Create a free GitHub account and a new **public** repository.
2. Upload `Momentum-Android-Studio-Project.zip` to the repository root (web UI: *Add file ▸ Upload files*).
3. The workflow in `.github/workflows/build-apk.yml` runs automatically and builds the debug APK.
4. Open the **Actions** tab → the latest run → download the **momentum-debug-apk** artifact.
5. Install the APK on your phone (you may need to allow "install from unknown sources").

### Permissions
- `POST_NOTIFICATIONS` — requested at runtime before the first notification (API 33+).
- `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM` — for precise habit reminders; the scheduler falls back to inexact alarms if unavailable.

---

## Notes & honest caveats

- This is a complete, internally consistent source tree — every screen, view model, DAO and repository referenced by the navigation graph is implemented, and there are no `TODO` stubs or placeholder returns in the logic.
- It has **not been compiled** in this environment (no Android SDK / Gradle toolchain is available here). Treat the first `assembleDebug` as the verification step: if your toolchain differs, pin versions in `gradle/libs.versions.toml`.
- The "on-device AI" features (Momentum Coach, insights) are deliberately **local heuristics over your own data** — no network calls, no data leaves the device. There is no bundled multi-hundred-megabyte model; if you want an on-device LLM later, add MediaPipe/ML Kit and wire it behind the `aiCoachEnabled` setting.
- `fallbackToDestructiveMigration()` is enabled for the first release. Before shipping real user data, add proper Room migrations.
