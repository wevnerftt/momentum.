package com.momentum.app.reminder

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.momentum.app.MainActivity
import com.momentum.app.R
import com.momentum.app.core.Constants
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val reminders = NotificationChannel(
            Constants.NOTIF_CHANNEL_REMINDERS,
            context.getString(R.string.notification_channel_reminders),
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Gentle nudges for your habits and daily plan" }

        val focus = NotificationChannel(
            Constants.NOTIF_CHANNEL_FOCUS,
            context.getString(R.string.notification_channel_focus),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Focus session completion and breaks" }

        manager.createNotificationChannel(reminders)
        manager.createNotificationChannel(focus)
    }

    fun showHabitReminder(habitId: Long, habitName: String) {
        show(
            id = habitId.toInt(),
            channel = Constants.NOTIF_CHANNEL_REMINDERS,
            title = "Time for $habitName",
            text = "A small step now keeps your momentum going."
        )
    }

    fun showDailyDigest(openTasks: Int, habitsLeft: Int) {
        val body = buildString {
            if (habitsLeft > 0) append("$habitsLeft habit(s) still open. ")
            if (openTasks > 0) append("$openTasks task(s) on your list. ")
            if (habitsLeft == 0 && openTasks == 0) append("Everything is clear. Enjoy the calm.")
        }
        show(
            id = 9001,
            channel = Constants.NOTIF_CHANNEL_REMINDERS,
            title = "Your day at a glance",
            text = body.trim()
        )
    }

    fun showFocusComplete(minutes: Int) {
        show(
            id = 9002,
            channel = Constants.NOTIF_CHANNEL_FOCUS,
            title = "Focus session complete",
            text = "You stayed locked in for $minutes minutes. Take a breath."
        )
    }

    private fun show(id: Int, channel: String, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        runCatching { NotificationManagerCompat.from(context).notify(id, notification) }
    }
}
