package com.momentum.app.core

object Constants {
    const val DATABASE_NAME = "momentum.db"

    // Habit frequencies
    const val FREQ_DAILY = "DAILY"
    const val FREQ_WEEKLY = "WEEKLY"
    const val FREQ_CUSTOM = "CUSTOM"

    // Task priorities
    const val PRIORITY_LOW = 0
    const val PRIORITY_MEDIUM = 1
    const val PRIORITY_HIGH = 2

    // Goal categories
    const val GOAL_STUDENT = "STUDENT"
    const val GOAL_PERSONAL = "PERSONAL"
    const val GOAL_CAREER = "CAREER"
    const val GOAL_HEALTH = "HEALTH"

    val GOAL_CATEGORIES = listOf(GOAL_STUDENT, GOAL_PERSONAL, GOAL_CAREER, GOAL_HEALTH)

    // Focus
    const val DEFAULT_FOCUS_MINUTES = 25
    const val DEFAULT_SHORT_BREAK = 5
    const val DEFAULT_LONG_BREAK = 15

    // DataStore
    const val SETTINGS_DATASTORE = "momentum_settings"

    const val NOTIF_CHANNEL_REMINDERS = "momentum_reminders"
    const val NOTIF_CHANNEL_FOCUS = "momentum_focus"

    const val DAILY_DIGEST_WORK = "momentum_daily_digest"
}
