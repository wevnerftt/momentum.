package com.momentum.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.momentum.app.core.Constants
import com.momentum.app.data.local.dao.CategoryDao
import com.momentum.app.data.local.dao.FocusSessionDao
import com.momentum.app.data.local.dao.GoalDao
import com.momentum.app.data.local.dao.HabitDao
import com.momentum.app.data.local.dao.HabitLogDao
import com.momentum.app.data.local.dao.JournalDao
import com.momentum.app.data.local.dao.SubjectDao
import com.momentum.app.data.local.dao.TaskDao
import com.momentum.app.data.local.entity.CategoryEntity
import com.momentum.app.data.local.entity.FocusSessionEntity
import com.momentum.app.data.local.entity.GoalEntity
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.data.local.entity.HabitLogEntity
import com.momentum.app.data.local.entity.JournalEntity
import com.momentum.app.data.local.entity.SubjectEntity
import com.momentum.app.data.local.entity.TaskEntity

@Database(
    entities = [
        HabitEntity::class,
        HabitLogEntity::class,
        TaskEntity::class,
        GoalEntity::class,
        SubjectEntity::class,
        JournalEntity::class,
        FocusSessionEntity::class,
        CategoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MomentumDatabase : RoomDatabase() {

    abstract fun habitDao(): HabitDao
    abstract fun habitLogDao(): HabitLogDao
    abstract fun taskDao(): TaskDao
    abstract fun goalDao(): GoalDao
    abstract fun subjectDao(): SubjectDao
    abstract fun journalDao(): JournalDao
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        fun create(context: Context): MomentumDatabase =
            Room.databaseBuilder(context, MomentumDatabase::class.java, Constants.DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .build()
    }
}
