package com.momentum.app.ui.screens.student

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.SubjectEntity
import com.momentum.app.data.repository.SubjectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SubjectFormState(
    val id: Long = 0,
    val name: String = "",
    val colorHex: String = "#6366F1",
    val examDate: Long? = null,
    val targetHours: String = "10",
    val difficulty: Int = 2,
    val isEditing: Boolean = false,
    val saved: Boolean = false
) {
    val isValid: Boolean get() = name.isNotBlank()
}

@HiltViewModel
class AddEditSubjectViewModel @Inject constructor(
    private val subjectRepository: SubjectRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val subjectId: Long = savedStateHandle.get<Long>("subjectId") ?: -1L

    private val _state = MutableStateFlow(SubjectFormState())
    val state: StateFlow<SubjectFormState> = _state.asStateFlow()

    init { if (subjectId > 0) load(subjectId) }

    private fun load(id: Long) {
        viewModelScope.launch {
            val subject = subjectRepository.observeById(id).first() ?: return@launch
            _state.update {
                SubjectFormState(
                    id = subject.id,
                    name = subject.name,
                    colorHex = subject.colorHex,
                    examDate = subject.examDate,
                    targetHours = subject.targetHours.toString(),
                    difficulty = subject.difficulty,
                    isEditing = true
                )
            }
        }
    }

    fun setName(v: String) = _state.update { it.copy(name = v) }
    fun setColor(v: String) = _state.update { it.copy(colorHex = v) }
    fun setDifficulty(v: Int) = _state.update { it.copy(difficulty = v.coerceIn(1, 3)) }
    fun setTargetHours(v: String) = _state.update { it.copy(targetHours = v.filter { c -> c.isDigit() }) }
    fun setExamInDays(days: Long?) = _state.update {
        it.copy(examDate = days?.let { d -> DateUtils.millisOf(java.time.LocalDate.now().plusDays(d)) })
    }

    fun save() {
        val s = _state.value
        if (!s.isValid) return
        viewModelScope.launch {
            subjectRepository.upsert(
                SubjectEntity(
                    id = s.id,
                    name = s.name.trim(),
                    colorHex = s.colorHex,
                    examDate = s.examDate,
                    targetHours = s.targetHours.toIntOrNull() ?: 10,
                    difficulty = s.difficulty
                )
            )
            _state.update { it.copy(saved = true) }
        }
    }

    fun delete() {
        val id = _state.value.id
        if (id <= 0) return
        viewModelScope.launch {
            subjectRepository.observeById(id).first()?.let { subjectRepository.delete(it) }
            _state.update { it.copy(saved = true) }
        }
    }
}
