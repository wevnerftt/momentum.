package com.momentum.app.ui.util

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.vector.ImageVector

object IconMapper {

    /** Icon names offered in the habit / goal pickers. */
    val availableIcons: List<String> = listOf(
        "CheckCircle", "Favorite", "FitnessCenter", "DirectionsRun", "SelfImprovement",
        "LocalDrink", "Bedtime", "School", "Work", "Code", "AutoStories", "MusicNote",
        "Brush", "Lightbulb", "Language", "Spa", "Star", "Home", "Category"
    )

    fun iconFor(name: String): ImageVector = when (name) {
        "Favorite" -> Icons.Filled.Favorite
        "FitnessCenter" -> Icons.Filled.FitnessCenter
        "DirectionsRun" -> Icons.Filled.DirectionsRun
        "SelfImprovement" -> Icons.Filled.SelfImprovement
        "LocalDrink" -> Icons.Filled.LocalDrink
        "Bedtime" -> Icons.Filled.Bedtime
        "School" -> Icons.Filled.School
        "Work" -> Icons.Filled.Work
        "Code" -> Icons.Filled.Code
        "AutoStories" -> Icons.Filled.AutoStories
        "MusicNote" -> Icons.Filled.MusicNote
        "Brush" -> Icons.Filled.Brush
        "Lightbulb" -> Icons.Filled.Lightbulb
        "Language" -> Icons.Filled.Language
        "Spa" -> Icons.Filled.Spa
        "Star" -> Icons.Filled.Star
        "Home" -> Icons.Filled.Home
        "Category" -> Icons.Filled.Category
        else -> Icons.Filled.CheckCircle
    }
}
