package com.momentum.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette
val EmeraldGreen = Color(0xFF10B981)
val EmeraldDark = Color(0xFF059669)
val EmeraldLight = Color(0xFF34D399)

val DeepObsidian = Color(0xFF0F172A)
val SoftSlate = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val LiquidWhite = Color(0xFFF8FAFC)
val CloudGray = Color(0xFFE2E8F0)

val IndigoAccent = Color(0xFF6366F1)
val AmberAccent = Color(0xFFF59E0B)
val RoseAccent = Color(0xFFF43F5E)
val SkyAccent = Color(0xFF0EA5E9)
val VioletAccent = Color(0xFF8B5CF6)

/** Curated accent palette offered when creating habits, goals and subjects. */
val AccentPalette: List<Color> = listOf(
    EmeraldGreen, IndigoAccent, AmberAccent, RoseAccent,
    SkyAccent, VioletAccent, Color(0xFFEC4899), Color(0xFF14B8A6)
)

fun colorFromHex(hex: String): Color = try {
    Color(android.graphics.Color.parseColor(hex))
} catch (e: Exception) {
    EmeraldGreen
}

fun Color.toHex(): String = String.format(
    "#%02X%02X%02X",
    (red * 255).toInt(),
    (green * 255).toInt(),
    (blue * 255).toInt()
)
