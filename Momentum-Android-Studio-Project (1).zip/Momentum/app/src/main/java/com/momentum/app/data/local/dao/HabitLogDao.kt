package com.momentum.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.momentum.app.data.local.entity.HabitLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: HabitLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(logs: List<HabitLogEntity>)

    @Query("SELECT * FROM habit_logs WHERE habitId = :habitId AND epochDay = :epochDay LIMIT 1")
    suspend fun getForDay(habitId: Long, epochDay: Long): HabitLogEntity?

    @Query("SELECT * FROM habit_logs WHERE epochDay = :epochDay")
    fun observeForDay(epochDay: Long): Flow<List<HabitLogEntity>>

    @Query("SELECT * FROM habit_logs WHERE epochDay BETWEEN :from AND :to")
    fun observeBetween(from: Long, to: Long): Flow<List<HabitLogEntity>>

    @Query("SELECT COUNT(*) FROM habit_logs WHERE completed = 1 AND epochDay = :epochDay")
    fun observeCompletedCount(epochDay: Long): Flow<Int>

    @Query("SELECT COUNT(DISTINCT epochDay) FROM habit_logs WHERE completed = 1")
    fun observeDistinctCompletedDays(): Flow<Int>

    @Query("SELECT COUNT(*) FROM habit_logs WHERE habitId = :habitId AND completed = 1 AND epochDay BETWEEN :from AND :to")
    suspend fun countCompletedBetween(habitId: Long, from: Long, to: Long): Int

    @Query("SELECT * FROM habit_logs")
    suspend fun getAllOnce(): List<HabitLogEntity>

    @Query("DELETE FROM habit_logs WHERE habitId = :habitId AND epochDay = :epochDay")
    suspend fun deleteForDay(habitId: Long, epochDay: Long)

    @Query("DELETE FROM habit_logs")
    suspend fun deleteAll()
}
