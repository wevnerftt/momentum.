package com.momentum.app.data.repository

import com.momentum.app.data.local.dao.CategoryDao
import com.momentum.app.data.local.entity.CategoryEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CategoryRepository @Inject constructor(
    private val categoryDao: CategoryDao
) {
    fun observeAll(): Flow<List<CategoryEntity>> = categoryDao.observeAll()

    suspend fun upsert(category: CategoryEntity): Long =
        if (category.id == 0L) categoryDao.insert(category) else { categoryDao.update(category); category.id }

    suspend fun delete(category: CategoryEntity) = categoryDao.delete(category)

    suspend fun seedDefaultsIfEmpty() {
        if (categoryDao.count() > 0) return
        categoryDao.insertAll(defaultCategories())
    }

    private fun defaultCategories() = listOf(
        CategoryEntity(name = "Health", colorHex = "#10B981", icon = "Favorite", sortOrder = 0),
        CategoryEntity(name = "Mind", colorHex = "#6366F1", icon = "SelfImprovement", sortOrder = 1),
        CategoryEntity(name = "Study", colorHex = "#F59E0B", icon = "School", sortOrder = 2),
        CategoryEntity(name = "Work", colorHex = "#0EA5E9", icon = "Work", sortOrder = 3),
        CategoryEntity(name = "Home", colorHex = "#EC4899", icon = "Home", sortOrder = 4)
    )
}
