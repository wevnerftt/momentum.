package com.momentum.app.data.repository

import com.momentum.app.data.local.dao.GoalDao
import com.momentum.app.data.local.entity.GoalEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalRepository @Inject constructor(
    private val goalDao: GoalDao
) {
    fun observeActive(): Flow<List<GoalEntity>> = goalDao.observeActive()
    fun observeById(id: Long): Flow<GoalEntity?> = goalDao.observeById(id)

    suspend fun upsert(goal: GoalEntity): Long =
        if (goal.id == 0L) goalDao.insert(goal) else { goalDao.update(goal); goal.id }

    suspend fun delete(goal: GoalEntity) = goalDao.delete(goal)
    suspend fun setProgress(id: Long, progress: Float) = goalDao.setProgress(id, progress.coerceIn(0f, 1f))
}
