package com.momentum.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import com.momentum.app.core.Constants

@Entity(tableName = "goals")
@Serializable
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String? = null,
    val targetDate: Long? = null,
    val category: String = Constants.GOAL_PERSONAL,
    val progress: Float = 0f,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
