package com.momentum.app.ui.screens.today

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.util.Formatters
import com.momentum.app.ui.components.EmptyState
import com.momentum.app.ui.components.HabitRow
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.Pill
import com.momentum.app.ui.components.ProgressRing
import com.momentum.app.ui.components.SectionHeader
import com.momentum.app.ui.components.TaskRow
import com.momentum.app.ui.theme.colorFromHex
import com.momentum.app.ui.util.IconMapper

@Composable
fun TodayScreen(
    onOpenHabits: () -> Unit,
    onOpenTasks: () -> Unit,
    onOpenFocus: () -> Unit,
    onAddTask: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: TodayViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            TodayHeader(
                greeting = state.greeting,
                userName = state.userName,
                progress = state.completionPercentage,
                streak = state.currentStreak,
                focusMinutes = state.focusMinutesToday,
                onOpenSettings = onOpenSettings
            )
        }

        item {
            AiCoachCard(tip = state.aiTip)
        }

        if (state.overdueTasks.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Overdue",
                    titleColor = MaterialTheme.colorScheme.error,
                    actionLabel = "View all",
                    onAction = onOpenTasks
                )
            }
            items(state.overdueTasks, key = { "overdue-${it.id}" }) { task ->
                TaskRow(task = task, onToggle = { viewModel.completeTask(task.id) }, onClick = onOpenTasks)
            }
        }

        item {
            SectionHeader(
                title = "Today's Habits",
                actionLabel = "All habits",
                onAction = onOpenHabits
            )
        }

        if (state.habits.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Filled.CheckCircle,
                    title = "No habits yet",
                    subtitle = "Create your first habit and start stacking small wins."
                )
            }
        } else {
            items(state.habits, key = { "habit-${it.habit.id}" }) { habitUi ->
                HabitRow(
                    name = habitUi.habit.name,
                    icon = IconMapper.iconFor(habitUi.habit.icon),
                    color = colorFromHex(habitUi.habit.colorHex),
                    subtitle = habitSubtitle(habitUi),
                    isCompleted = habitUi.completed,
                    progressFraction = habitUi.progressFraction,
                    onToggle = { viewModel.toggleHabit(habitUi.habit.id) },
                    onClick = onOpenHabits
                )
            }
        }

        item {
            SectionHeader(
                title = "Tasks",
                actionLabel = "All tasks",
                onAction = onOpenTasks
            )
        }

        if (state.tasks.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Filled.BarChart,
                    title = "Nothing due today",
                    subtitle = "Add a task to keep the day structured."
                )
            }
        } else {
            items(state.tasks, key = { "task-${it.id}" }) { task ->
                TaskRow(task = task, onToggle = { viewModel.completeTask(task.id) }, onClick = onOpenTasks)
            }
        }

        item {
            MomentumCard(onClick = onOpenFocus) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.size(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Start a focus session", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Focused today: ${Formatters.hoursMinutes(state.focusMinutesToday)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(88.dp)) }
    }
}

private fun habitSubtitle(ui: HabitUi): String {
    val target = ui.habit.targetQuantity
    return when {
        target != null && target > 1 ->
            "${ui.value} / $target ${ui.habit.targetUnit ?: ""}".trim()
        ui.habit.targetDurationMinutes != null ->
            "${ui.habit.targetDurationMinutes} min"
        else -> if (ui.completed) "Done" else "Tap to complete"
    }
}

@Composable
private fun TodayHeader(
    greeting: String,
    userName: String,
    progress: Float,
    streak: Int,
    focusMinutes: Int,
    onOpenSettings: () -> Unit
) {
    MomentumCard {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (userName.isBlank()) greeting else "$greeting, $userName",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Let's make today count.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                androidx.compose.material3.IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings")
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                ProgressRing(progress = progress, size = 76.dp, strokeWidth = 9.dp) {
                    Text(
                        Formatters.percent(progress),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                Spacer(Modifier.size(18.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Daily progress", style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill(
                            text = "$streak day streak",
                            color = MaterialTheme.colorScheme.tertiary,
                            icon = Icons.Filled.LocalFireDepartment
                        )
                        Pill(
                            text = Formatters.hoursMinutes(focusMinutes),
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AiCoachCard(tip: String) {
    MomentumCard(
        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.size(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Momentum Coach", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(2.dp))
                Text(
                    tip,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Start
                )
            }
        }
    }
}
