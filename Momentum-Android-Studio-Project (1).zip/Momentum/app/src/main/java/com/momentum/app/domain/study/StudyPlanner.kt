package com.momentum.app.domain.study

import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.SubjectEntity
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class StudyBlock(
    val subjectId: Long,
    val subjectName: String,
    val colorHex: String,
    val epochDay: Long,
    val minutes: Int
)

/**
 * A lightweight, deterministic study scheduler. It spreads each subject's remaining
 * target hours across the days left before its exam, weighting by difficulty and urgency,
 * then fits the result into a daily study budget.
 */
object StudyPlanner {

    fun plan(
        subjects: List<SubjectEntity>,
        dailyBudgetMinutes: Int,
        daysAhead: Int = 7
    ): List<StudyBlock> {
        if (subjects.isEmpty() || dailyBudgetMinutes <= 0) return emptyList()

        val today = DateUtils.todayEpochDay()
        val blocks = mutableListOf<StudyBlock>()

        for (offset in 0 until daysAhead) {
            val day = today + offset

            val candidates = subjects.mapNotNull { subject ->
                val examDay = subject.examDate?.let { DateUtils.epochDayOf(it) }
                val daysLeft = if (examDay == null) 30L else max(1L, examDay - day)
                if (examDay != null && examDay < day) return@mapNotNull null

                val difficultyWeight = 0.75f + (subject.difficulty - 1) * 0.35f
                val urgency = (30.0 / daysLeft.toDouble()).coerceAtMost(3.0).toFloat()
                val weight = difficultyWeight * urgency
                subject to weight
            }

            if (candidates.isEmpty()) continue

            val totalWeight = candidates.sumOf { it.second.toDouble() }.toFloat()
            if (totalWeight <= 0f) continue

            var allocated = 0
            candidates.forEachIndexed { index, (subject, weight) ->
                val raw = (dailyBudgetMinutes * (weight / totalWeight))
                val minutes = if (index == candidates.lastIndex)
                    max(5, dailyBudgetMinutes - allocated)
                else max(5, raw.roundToInt())
                allocated += minutes

                blocks.add(
                    StudyBlock(
                        subjectId = subject.id,
                        subjectName = subject.name,
                        colorHex = subject.colorHex,
                        epochDay = day,
                        minutes = min(minutes, 180)
                    )
                )
            }
        }

        return blocks
    }

    fun daysUntilExam(subject: SubjectEntity): Long? {
        val examDay = subject.examDate?.let { DateUtils.epochDayOf(it) } ?: return null
        return examDay - DateUtils.todayEpochDay()
    }
}
