package com.momentum.app.ui.screens.tasks

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.Constants
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.TaskEntity
import com.momentum.app.data.repository.TaskRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TaskFormState(
    val id: Long = 0,
    val title: String = "",
    val description: String = "",
    val dueDate: Long? = null,
    val priority: Int = Constants.PRIORITY_MEDIUM,
    val estimatedMinutes: String = "",
    val isEditing: Boolean = false,
    val saved: Boolean = false
) {
    val isValid: Boolean get() = title.isNotBlank()
}

@HiltViewModel
class AddEditTaskViewModel @Inject constructor(
    private val taskRepository: TaskRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val taskId: Long = savedStateHandle.get<Long>("taskId") ?: -1L

    private val _state = MutableStateFlow(TaskFormState())
    val state: StateFlow<TaskFormState> = _state.asStateFlow()

    init {
        if (taskId > 0) load(taskId)
    }

    private fun load(id: Long) {
        viewModelScope.launch {
            val task = taskRepository.getById(id) ?: return@launch
            _state.update {
                TaskFormState(
                    id = task.id,
                    title = task.title,
                    description = task.description.orEmpty(),
                    dueDate = task.dueDate,
                    priority = task.priority,
                    estimatedMinutes = task.estimatedMinutes?.toString().orEmpty(),
                    isEditing = true
                )
            }
        }
    }

    fun setTitle(v: String) = _state.update { it.copy(title = v) }
    fun setDescription(v: String) = _state.update { it.copy(description = v) }
    fun setPriority(v: Int) = _state.update { it.copy(priority = v) }
    fun setEstimated(v: String) = _state.update { it.copy(estimatedMinutes = v.filter { c -> c.isDigit() }) }

    fun setDueInDays(days: Long?) = _state.update {
        it.copy(dueDate = days?.let { d -> DateUtils.millisOf(java.time.LocalDate.now().plusDays(d)) })
    }

    fun save() {
        val s = _state.value
        if (!s.isValid) return
        viewModelScope.launch {
            val task = TaskEntity(
                id = s.id,
                title = s.title.trim(),
                description = s.description.trim().ifBlank { null },
                dueDate = s.dueDate,
                priority = s.priority,
                estimatedMinutes = s.estimatedMinutes.toIntOrNull()
            )
            taskRepository.upsert(task)
            _state.update { it.copy(saved = true) }
        }
    }

    fun delete() {
        val id = _state.value.id
        if (id <= 0) return
        viewModelScope.launch {
            taskRepository.getById(id)?.let { taskRepository.delete(it) }
            _state.update { it.copy(saved = true) }
        }
    }
}
