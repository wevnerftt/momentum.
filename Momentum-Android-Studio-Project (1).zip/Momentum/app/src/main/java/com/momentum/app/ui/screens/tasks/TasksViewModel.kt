package com.momentum.app.ui.screens.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.TaskEntity
import com.momentum.app.data.repository.TaskRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class TaskFilter { ACTIVE, COMPLETED, ALL }

data class TasksUiState(
    val overdue: List<TaskEntity> = emptyList(),
    val today: List<TaskEntity> = emptyList(),
    val upcoming: List<TaskEntity> = emptyList(),
    val noDate: List<TaskEntity> = emptyList(),
    val completed: List<TaskEntity> = emptyList(),
    val filter: TaskFilter = TaskFilter.ACTIVE
) {
    val activeCount: Int get() = overdue.size + today.size + upcoming.size + noDate.size
    val isEmpty: Boolean
        get() = when (filter) {
            TaskFilter.ACTIVE -> activeCount == 0
            TaskFilter.COMPLETED -> completed.isEmpty()
            TaskFilter.ALL -> activeCount == 0 && completed.isEmpty()
        }
}

@HiltViewModel
class TasksViewModel @Inject constructor(
    private val taskRepository: TaskRepository
) : ViewModel() {

    private val todayStart = DateUtils.startOfTodayMillis()
    private val todayEnd = DateUtils.endOfDayMillis(DateUtils.todayEpochDay())

    private var filter = TaskFilter.ACTIVE

    val state: StateFlow<TasksUiState> = taskRepository.observeAll()
        .map { tasks -> group(tasks) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TasksUiState())

    private fun group(tasks: List<TaskEntity>): TasksUiState {
        val active = tasks.filter { !it.isCompleted }
        val completed = tasks.filter { it.isCompleted }
        val overdue = active.filter { it.dueDate != null && it.dueDate < todayStart }
            .sortedBy { it.dueDate }
        val dueToday = active.filter { it.dueDate != null && it.dueDate in todayStart..todayEnd }
            .sortedByDescending { it.priority }
        val upcoming = active.filter { it.dueDate != null && it.dueDate > todayEnd }
            .sortedBy { it.dueDate }
        val noDate = active.filter { it.dueDate == null }.sortedByDescending { it.priority }

        return TasksUiState(
            overdue = overdue,
            today = dueToday,
            upcoming = upcoming,
            noDate = noDate,
            completed = completed,
            filter = filter
        )
    }

    fun setFilter(value: TaskFilter) { filter = value }

    fun toggle(taskId: Long) {
        viewModelScope.launch { taskRepository.toggleCompleted(taskId) }
    }

    fun delete(task: TaskEntity) {
        viewModelScope.launch { taskRepository.delete(task) }
    }
}
