package com.momentum.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.momentum.app.data.local.entity.FocusSessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FocusSessionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: FocusSessionEntity): Long

    @Query("SELECT * FROM focus_sessions ORDER BY startedAt DESC")
    fun observeAll(): Flow<List<FocusSessionEntity>>

    @Query("SELECT * FROM focus_sessions WHERE startedAt BETWEEN :from AND :to ORDER BY startedAt DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<FocusSessionEntity>>

    @Query("SELECT COALESCE(SUM(durationMinutes), 0) FROM focus_sessions WHERE completed = 1 AND startedAt BETWEEN :from AND :to")
    fun observeMinutesBetween(from: Long, to: Long): Flow<Int>

    @Query("SELECT COALESCE(SUM(durationMinutes), 0) FROM focus_sessions WHERE completed = 1")
    fun observeTotalMinutes(): Flow<Int>

    @Query("SELECT COUNT(*) FROM focus_sessions WHERE completed = 1")
    fun observeSessionCount(): Flow<Int>

    @Query("SELECT * FROM focus_sessions")
    suspend fun getAllOnce(): List<FocusSessionEntity>

    @Query("DELETE FROM focus_sessions")
    suspend fun deleteAll()
}
