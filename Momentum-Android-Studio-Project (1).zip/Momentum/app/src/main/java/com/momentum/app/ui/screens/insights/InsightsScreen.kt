package com.momentum.app.ui.screens.insights

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.util.Formatters
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.ProgressRing
import com.momentum.app.ui.components.SectionHeader

@Composable
fun InsightsScreen(
    onOpenGoals: () -> Unit,
    onOpenStudent: () -> Unit,
    onOpenJournal: () -> Unit,
    viewModel: InsightsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "Insights",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        item {
            MomentumCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        progress = if (state.weekDays.isEmpty()) 0f
                        else state.habitsByDay.map { it.value }.average().toFloat(),
                        size = 82.dp,
                        strokeWidth = 9.dp
                    ) {
                        Text(
                            Formatters.percent(
                                if (state.weekDays.isEmpty()) 0f
                                else state.habitsByDay.map { it.value }.average().toFloat()
                            ),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    Spacer(Modifier.width(18.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Weekly habit consistency", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Current streak: ${state.currentStreak} days · Best: ${state.longestStreak} days",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "Focus this week",
                    value = Formatters.hoursMinutes(state.focusMinutesThisWeek)
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "Tasks done",
                    value = state.tasksCompletedThisWeek.toString()
                )
            }
        }

        item { SectionHeader(title = "Focus minutes (last 7 days)") }
        item {
            MomentumCard {
                BarChart(points = state.focusByDay)
            }
        }

        item { SectionHeader(title = "Habit completion") }
        item {
            MomentumCard {
                BarChart(
                    points = state.habitsByDay,
                    barColor = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f)
                )
            }
        }

        item { SectionHeader(title = "Momentum Coach") }
        items(state.insights, key = { it }) { insight ->
            MomentumCard(
                containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(insight, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item { SectionHeader(title = "More tools") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ToolCard(
                    modifier = Modifier.weight(1f),
                    title = "Goals",
                    icon = { Icon(Icons.Filled.Flag, contentDescription = null) },
                    onClick = onOpenGoals
                )
                ToolCard(
                    modifier = Modifier.weight(1f),
                    title = "Student",
                    icon = { Icon(Icons.Filled.School, contentDescription = null) },
                    onClick = onOpenStudent
                )
                ToolCard(
                    modifier = Modifier.weight(1f),
                    title = "Journal",
                    icon = { Icon(Icons.Filled.Book, contentDescription = null) },
                    onClick = onOpenJournal
                )
            }
        }

        item { Spacer(Modifier.height(88.dp)) }
    }
}

@Composable
private fun StatCard(modifier: Modifier = Modifier, title: String, value: String) {
    MomentumCard(modifier = modifier) {
        Column {
            Text(value, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(4.dp))
            Text(
                title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ToolCard(
    modifier: Modifier = Modifier,
    title: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    MomentumCard(modifier = modifier, onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            icon()
            Spacer(Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.labelLarge)
        }
    }
}
