package com.momentum.app.ui.screens.focus

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.util.Formatters
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.Pill
import com.momentum.app.ui.components.ProgressRing

@Composable
fun FocusScreen(viewModel: FocusViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            when (state.mode) {
                FocusMode.WORK -> "Focus"
                FocusMode.SHORT_BREAK -> "Short break"
                FocusMode.LONG_BREAK -> "Long break"
            },
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FocusMode.entries.forEach { mode ->
                FilterChip(
                    selected = state.mode == mode,
                    onClick = { viewModel.selectMode(mode) },
                    label = {
                        Text(
                            when (mode) {
                                FocusMode.WORK -> "Focus"
                                FocusMode.SHORT_BREAK -> "Short"
                                FocusMode.LONG_BREAK -> "Long"
                            }
                        )
                    }
                )
            }
        }

        Spacer(Modifier.height(32.dp))

        ProgressRing(
            progress = state.progress,
            size = 268.dp,
            strokeWidth = 14.dp
        ) {
            Text(
                Formatters.mmss(state.remainingSeconds),
                style = MaterialTheme.typography.displayMedium
            )
        }

        Spacer(Modifier.height(36.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledIconButton(onClick = viewModel::reset) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reset")
            }
            FilledIconButton(
                onClick = viewModel::toggle,
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    if (state.isRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (state.isRunning) "Pause" else "Start",
                    modifier = Modifier.size(36.dp)
                )
            }
            FilledIconButton(onClick = viewModel::skip) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Skip")
            }
        }

        Spacer(Modifier.height(32.dp))

        MomentumCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatBlock("Sessions", state.sessionsToday.toString())
                StatBlock("Focused", Formatters.hoursMinutes(state.minutesToday))
                StatBlock("Cycle", "${state.completedInCycle % 4}/4")
            }
        }
    }
}

@Composable
private fun StatBlock(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Pill(text = label, color = MaterialTheme.colorScheme.secondary)
    }
}
