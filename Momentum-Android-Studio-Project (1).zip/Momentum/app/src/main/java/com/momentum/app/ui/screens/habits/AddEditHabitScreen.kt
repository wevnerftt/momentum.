@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.momentum.app.ui.screens.habits

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.Constants
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumPrimaryButton
import com.momentum.app.ui.components.MomentumTextField
import com.momentum.app.ui.theme.AccentPalette
import com.momentum.app.ui.theme.colorFromHex
import com.momentum.app.ui.theme.toHex
import com.momentum.app.ui.util.IconMapper

private val dayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
private val durationOptions = listOf("10", "15", "20", "30", "45", "60")
private val reminderOptions = listOf("06:30", "08:00", "09:00", "12:00", "18:00", "21:00")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditHabitScreen(
    onDone: () -> Unit,
    viewModel: AddEditHabitViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.saved) { if (state.saved) onDone() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEditing) "Edit habit" else "New habit") },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (state.isEditing) {
                        IconButton(onClick = viewModel::delete) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MomentumCard {
                Column {
                    MomentumTextField(
                        value = state.name,
                        onValueChange = viewModel::setName,
                        label = "Habit name",
                        placeholder = "e.g. Read 10 pages"
                    )
                    Spacer(Modifier.height(12.dp))
                    MomentumTextField(
                        value = state.description,
                        onValueChange = viewModel::setDescription,
                        label = "Description (optional)",
                        singleLine = false,
                        minLines = 2
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Icon", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconMapper.availableIcons.forEach { name ->
                            val selected = state.icon == name
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { viewModel.setIcon(name) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    IconMapper.iconFor(name),
                                    contentDescription = name,
                                    tint = if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Colour", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AccentPalette.forEach { color ->
                            val selected = state.colorHex.equals(color.toHex(), ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (selected) 3.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        shape = CircleShape
                                    )
                                    .clickable { viewModel.setColor(color.toHex()) }
                            )
                        }
                    }
                }
            }

            MomentumCard {
                Column {
                    Text("Repeat", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(Constants.FREQ_DAILY to "Daily", Constants.FREQ_WEEKLY to "Weekly",
                            Constants.FREQ_CUSTOM to "Custom").forEach { (value, label) ->
                            FilterChip(
                                selected = state.frequency == value,
                                onClick = { viewModel.setFrequency(value) },
                                label = { Text(label) }
                            )
                        }
                    }
                    if (state.frequency == Constants.FREQ_CUSTOM) {
                        Spacer(Modifier.height(10.dp))
                        androidx.compose.foundation.layout.FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            dayLabels.forEachIndexed { index, label ->
                                val day = index + 1
                                FilterChip(
                                    selected = state.customDays.contains(day),
                                    onClick = { viewModel.toggleCustomDay(day) },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                }
            }

            MomentumCard {
                Column {
                    ToggleRow(
                        title = "Track a quantity",
                        subtitle = "e.g. 8 glasses of water",
                        checked = state.isQuantity,
                        onCheckedChange = viewModel::setQuantityEnabled
                    )
                    if (state.isQuantity) {
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MomentumTextField(
                                value = state.targetQuantity,
                                onValueChange = viewModel::setQuantity,
                                label = "Target",
                                modifier = Modifier.weight(1f),
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            )
                            MomentumTextField(
                                value = state.targetUnit,
                                onValueChange = viewModel::setUnit,
                                label = "Unit",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    ToggleRow(
                        title = "Time-based habit",
                        subtitle = "Track minutes instead of a count",
                        checked = state.isTimeBased,
                        onCheckedChange = viewModel::setTimeBased
                    )
                    if (state.isTimeBased) {
                        Spacer(Modifier.height(12.dp))
                        androidx.compose.foundation.layout.FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            durationOptions.forEach { minutes ->
                                FilterChip(
                                    selected = state.targetDurationMinutes == minutes,
                                    onClick = { viewModel.setDuration(minutes) },
                                    label = { Text("$minutes min") }
                                )
                            }
                        }
                    }
                }
            }

            MomentumCard {
                Column {
                    Text("Reminder", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        reminderOptions.forEach { time ->
                            FilterChip(
                                selected = state.reminderTime == time,
                                onClick = { viewModel.setReminder(time) },
                                label = { Text(time) }
                            )
                        }
                    }
                }
            }

            MomentumPrimaryButton(
                text = "Save habit",
                onClick = viewModel::save,
                enabled = state.isValid,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
