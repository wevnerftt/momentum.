package com.momentum.app.data.repository

import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.dao.HabitDao
import com.momentum.app.data.local.dao.HabitLogDao
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.data.local.entity.HabitLogEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HabitRepository @Inject constructor(
    private val habitDao: HabitDao,
    private val habitLogDao: HabitLogDao
) {

    fun observeActiveHabits(): Flow<List<HabitEntity>> = habitDao.observeActive()

    fun observeAllHabits(): Flow<List<HabitEntity>> = habitDao.observeAll()

    fun observeHabit(id: Long): Flow<HabitEntity?> = habitDao.observeById(id)

    suspend fun getHabit(id: Long): HabitEntity? = habitDao.getById(id)

    suspend fun getActiveHabits(): List<HabitEntity> = habitDao.getActiveOnce()

    suspend fun upsertHabit(habit: HabitEntity): Long =
        if (habit.id == 0L) habitDao.insert(habit) else { habitDao.update(habit); habit.id }

    suspend fun deleteHabit(habit: HabitEntity) = habitDao.delete(habit)

    suspend fun setArchived(id: Long, archived: Boolean) = habitDao.setArchived(id, archived)

    fun observeLogsForDay(epochDay: Long): Flow<List<HabitLogEntity>> =
        habitLogDao.observeForDay(epochDay)

    fun observeLogsBetween(from: Long, to: Long): Flow<List<HabitLogEntity>> =
        habitLogDao.observeBetween(from, to)

    fun observeCompletedCount(epochDay: Long): Flow<Int> =
        habitLogDao.observeCompletedCount(epochDay)

    fun observeCompletedEpochDays(): Flow<Set<Long>> =
        habitLogDao.observeBetween(0, Long.MAX_VALUE)
            .map { logs -> logs.filter { it.completed }.map { it.epochDay }.toSet() }

    suspend fun getLog(habitId: Long, epochDay: Long): HabitLogEntity? =
        habitLogDao.getForDay(habitId, epochDay)

    /**
     * Toggle completion for a habit on a given day. Quantity habits advance by one unit
     * until the target is met, then reset.
     */
    suspend fun toggleHabit(habit: HabitEntity, epochDay: Long) {
        val existing = habitLogDao.getForDay(habit.id, epochDay)
        val target = habit.targetQuantity
        if (target == null || target <= 1) {
            if (existing?.completed == true) {
                habitLogDao.deleteForDay(habit.id, epochDay)
            } else {
                habitLogDao.upsert(
                    HabitLogEntity(habitId = habit.id, epochDay = epochDay, value = 1, completed = true)
                )
            }
        } else {
            val currentValue = existing?.value ?: 0
            val nextValue = if (currentValue >= target) 0 else currentValue + 1
            if (nextValue == 0) {
                habitLogDao.deleteForDay(habit.id, epochDay)
            } else {
                habitLogDao.upsert(
                    HabitLogEntity(
                        habitId = habit.id,
                        epochDay = epochDay,
                        value = nextValue,
                        completed = nextValue >= target
                    )
                )
            }
        }
    }

    suspend fun logFocusForHabit(habitId: Long, epochDay: Long, minutes: Int) {
        habitLogDao.upsert(
            HabitLogEntity(habitId = habitId, epochDay = epochDay, value = minutes, completed = true)
        )
    }

    /** Completion ratio for the scheduled habits of a given day, based on a set of completed habit ids. */
    fun completionRatio(
        habits: List<HabitEntity>,
        completedHabitIds: Set<Long>,
        epochDay: Long
    ): Float {
        val scheduled = habits.filter { it.scheduledOn(DateUtils.isoWeekday(epochDay)) }
        if (scheduled.isEmpty()) return 0f
        val done = scheduled.count { completedHabitIds.contains(it.id) }
        return done.toFloat() / scheduled.size.toFloat()
    }
}
