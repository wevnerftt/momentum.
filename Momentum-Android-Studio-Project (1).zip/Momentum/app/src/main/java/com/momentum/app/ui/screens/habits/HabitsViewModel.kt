package com.momentum.app.ui.screens.habits

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.CategoryEntity
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.data.repository.CategoryRepository
import com.momentum.app.data.repository.HabitRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HabitsUiState(
    val habits: List<HabitEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val weekDays: List<Long> = emptyList(),
    val selectedDay: Long = DateUtils.todayEpochDay(),
    val completedOnSelected: Set<Long> = emptySet(),
    val weeklyCounts: Map<Long, Int> = emptyMap()
)

@HiltViewModel
class HabitsViewModel @Inject constructor(
    private val habitRepository: HabitRepository,
    categoryRepository: CategoryRepository
) : ViewModel() {

    private val weekDays = DateUtils.lastEpochDays(7)
    private val selectedDay = MutableStateFlow(DateUtils.todayEpochDay())

    val state: StateFlow<HabitsUiState> = combine(
        habitRepository.observeActiveHabits(),
        habitRepository.observeLogsBetween(weekDays.first(), weekDays.last()),
        categoryRepository.observeAll(),
        selectedDay
    ) { habits, logs, categories, day ->
        val completedOnSelected = logs
            .filter { it.epochDay == day && it.completed }
            .map { it.habitId }
            .toSet()
        val weeklyCounts = logs.filter { it.completed }
            .groupingBy { it.habitId }
            .eachCount()
        HabitsUiState(
            habits = habits,
            categories = categories,
            weekDays = weekDays,
            selectedDay = day,
            completedOnSelected = completedOnSelected,
            weeklyCounts = weeklyCounts
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HabitsUiState(weekDays = weekDays))

    fun selectDay(day: Long) { selectedDay.value = day }

    fun toggleHabit(habitId: Long) {
        viewModelScope.launch {
            val habit = habitRepository.getHabit(habitId) ?: return@launch
            habitRepository.toggleHabit(habit, selectedDay.value)
        }
    }

    fun archiveHabit(habitId: Long) {
        viewModelScope.launch { habitRepository.setArchived(habitId, true) }
    }
}
