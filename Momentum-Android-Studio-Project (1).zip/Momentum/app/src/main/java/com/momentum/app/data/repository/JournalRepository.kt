package com.momentum.app.data.repository

import com.momentum.app.data.local.dao.JournalDao
import com.momentum.app.data.local.entity.JournalEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class JournalRepository @Inject constructor(
    private val journalDao: JournalDao
) {
    fun observeAll(): Flow<List<JournalEntity>> = journalDao.observeAll()
    fun search(query: String): Flow<List<JournalEntity>> = journalDao.search(query)
    fun observeById(id: Long): Flow<JournalEntity?> = journalDao.observeById(id)
    fun observeAverageMood(): Flow<Float?> = journalDao.observeAverageMood()

    suspend fun upsert(entry: JournalEntity): Long =
        if (entry.id == 0L) journalDao.insert(entry)
        else { journalDao.update(entry.copy(updatedAt = System.currentTimeMillis())); entry.id }

    suspend fun delete(entry: JournalEntity) = journalDao.delete(entry)
}
