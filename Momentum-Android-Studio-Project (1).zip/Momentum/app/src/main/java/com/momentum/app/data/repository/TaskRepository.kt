package com.momentum.app.data.repository

import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.dao.TaskDao
import com.momentum.app.data.local.entity.TaskEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskRepository @Inject constructor(
    private val taskDao: TaskDao
) {

    fun observeAll(): Flow<List<TaskEntity>> = taskDao.observeAll()

    fun observeToday(): Flow<List<TaskEntity>> =
        taskDao.observeDueBetween(DateUtils.startOfTodayMillis(), DateUtils.endOfDayMillis(DateUtils.todayEpochDay()))

    fun observeOverdue(): Flow<List<TaskEntity>> = taskDao.observeOverdue(DateUtils.startOfTodayMillis())

    fun observeForGoal(goalId: Long): Flow<List<TaskEntity>> = taskDao.observeForGoal(goalId)

    fun observeForSubject(subjectId: Long): Flow<List<TaskEntity>> = taskDao.observeForSubject(subjectId)

    fun observeById(id: Long): Flow<TaskEntity?> = taskDao.observeById(id)

    suspend fun getById(id: Long): TaskEntity? = taskDao.getById(id)

    fun observeOpenCount(): Flow<Int> = taskDao.observeOpenCount()

    fun observeCompletedBetween(from: Long, to: Long): Flow<Int> =
        taskDao.observeCompletedBetween(from, to)

    suspend fun upsert(task: TaskEntity): Long =
        if (task.id == 0L) taskDao.insert(task) else { taskDao.update(task); task.id }

    suspend fun delete(task: TaskEntity) = taskDao.delete(task)

    suspend fun setCompleted(id: Long, completed: Boolean) =
        taskDao.setCompleted(id, completed, if (completed) System.currentTimeMillis() else null)

    suspend fun toggleCompleted(id: Long) {
        val task = taskDao.getById(id) ?: return
        setCompleted(id, !task.isCompleted)
    }
}
