package com.momentum.app.data.backup

import android.content.Context
import android.net.Uri
import com.momentum.app.data.local.MomentumDatabase
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Full-fidelity JSON backup of the local database using the Storage Access Framework.
 * Entities are serialised with kotlinx.serialization and streamed straight to the chosen Uri.
 */
@Singleton
class DataBackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val db: MomentumDatabase
) {
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    suspend fun exportTo(uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = BackupPayload(
                habits = db.habitDao().getAllOnce(),
                habitLogs = db.habitLogDao().getAllOnce(),
                tasks = db.taskDao().getAllOnce(),
                goals = db.goalDao().getAllOnce(),
                subjects = db.subjectDao().getAllOnce(),
                journal = db.journalDao().getAllOnce(),
                focusSessions = db.focusSessionDao().getAllOnce(),
                categories = db.categoryDao().getAllOnce()
            )
            val text = json.encodeToString(BackupPayload.serializer(), payload)
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: error("Unable to open the destination file")

            payload.habits.size + payload.tasks.size + payload.journal.size +
                payload.habitLogs.size + payload.goals.size + payload.subjects.size +
                payload.focusSessions.size
        }
    }

    suspend fun importFrom(uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val text = context.contentResolver.openInputStream(uri)?.use { input ->
                input.readBytes().toString(Charsets.UTF_8)
            } ?: error("Unable to read the selected file")

            val payload = json.decodeFromString(BackupPayload.serializer(), text)

            payload.categories.forEach { db.categoryDao().insert(it) }
            payload.goals.forEach { db.goalDao().insert(it) }
            payload.subjects.forEach { db.subjectDao().insert(it) }
            payload.habits.forEach { db.habitDao().insert(it) }
            payload.habitLogs.forEach { db.habitLogDao().upsert(it) }
            payload.tasks.forEach { db.taskDao().insert(it) }
            payload.journal.forEach { db.journalDao().insert(it) }
            payload.focusSessions.forEach { db.focusSessionDao().insert(it) }

            payload.habits.size + payload.tasks.size + payload.journal.size
        }
    }
}
