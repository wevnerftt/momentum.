package com.momentum.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import com.momentum.app.core.Constants

@Entity(tableName = "habits")
@Serializable
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String? = null,
    val icon: String = "CheckCircle",
    val colorHex: String = "#10B981",
    val categoryId: Long? = null,
    val frequency: String = Constants.FREQ_DAILY,
    /** Comma separated ISO weekdays, e.g. "1,3,5". Only used when frequency == CUSTOM. */
    val customDays: String? = null,
    val targetQuantity: Int? = null,
    val targetUnit: String? = null,
    val isTimeBased: Boolean = false,
    val targetDurationMinutes: Int? = null,
    /** "HH:mm" 24h. */
    val reminderTime: String? = null,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun scheduledOn(isoWeekday: Int): Boolean = when (frequency) {
        Constants.FREQ_DAILY -> true
        Constants.FREQ_WEEKLY -> true
        Constants.FREQ_CUSTOM -> customDays
            ?.split(",")
            ?.mapNotNull { it.trim().toIntOrNull() }
            ?.contains(isoWeekday) == true
        else -> true
    }
}
