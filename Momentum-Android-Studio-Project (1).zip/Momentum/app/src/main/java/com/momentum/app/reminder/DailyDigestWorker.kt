package com.momentum.app.reminder

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.repository.HabitRepository
import com.momentum.app.data.repository.SettingsRepository
import com.momentum.app.data.repository.TaskRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

@HiltWorker
class DailyDigestWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val habitRepository: HabitRepository,
    private val taskRepository: TaskRepository,
    private val settingsRepository: SettingsRepository,
    private val notificationHelper: NotificationHelper
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val settings = settingsRepository.settings.first()
        if (!settings.dailyDigestEnabled || !settings.remindersEnabled) return Result.success()

        val today = DateUtils.todayEpochDay()
        val habits = habitRepository.getActiveHabits()
        val logs = habitRepository.observeLogsForDay(today).first()
        val completedIds = logs.filter { it.completed }.map { it.habitId }.toSet()

        val scheduled = habits.filter { it.scheduledOn(DateUtils.isoWeekday(today)) }
        val habitsLeft = scheduled.count { !completedIds.contains(it.id) }
        val openTasks = taskRepository.observeOpenCount().first()

        if (habitsLeft > 0 || openTasks > 0) {
            notificationHelper.showDailyDigest(openTasks = openTasks, habitsLeft = habitsLeft)
        }
        return Result.success()
    }
}
