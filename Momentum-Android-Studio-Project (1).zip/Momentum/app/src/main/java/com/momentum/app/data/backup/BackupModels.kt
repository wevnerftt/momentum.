package com.momentum.app.data.backup

import com.momentum.app.data.local.entity.CategoryEntity
import com.momentum.app.data.local.entity.FocusSessionEntity
import com.momentum.app.data.local.entity.GoalEntity
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.data.local.entity.HabitLogEntity
import com.momentum.app.data.local.entity.JournalEntity
import com.momentum.app.data.local.entity.SubjectEntity
import com.momentum.app.data.local.entity.TaskEntity
import kotlinx.serialization.Serializable

@Serializable
data class BackupPayload(
    val schemaVersion: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val habits: List<HabitEntity> = emptyList(),
    val habitLogs: List<HabitLogEntity> = emptyList(),
    val tasks: List<TaskEntity> = emptyList(),
    val goals: List<GoalEntity> = emptyList(),
    val subjects: List<SubjectEntity> = emptyList(),
    val journal: List<JournalEntity> = emptyList(),
    val focusSessions: List<FocusSessionEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList()
)
