package com.momentum.app.ui.screens.focus

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.Constants
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.FocusSessionEntity
import com.momentum.app.data.repository.FocusRepository
import com.momentum.app.data.repository.SettingsRepository
import com.momentum.app.reminder.NotificationHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class FocusMode { WORK, SHORT_BREAK, LONG_BREAK }

data class FocusUiState(
    val mode: FocusMode = FocusMode.WORK,
    val totalSeconds: Int = 25 * 60,
    val remainingSeconds: Int = 25 * 60,
    val isRunning: Boolean = false,
    val workMinutes: Int = Constants.DEFAULT_FOCUS_MINUTES,
    val shortBreakMinutes: Int = Constants.DEFAULT_SHORT_BREAK,
    val longBreakMinutes: Int = Constants.DEFAULT_LONG_BREAK,
    val sessionsToday: Int = 0,
    val minutesToday: Int = 0,
    val completedInCycle: Int = 0
) {
    val progress: Float
        get() = if (totalSeconds <= 0) 0f
        else (totalSeconds - remainingSeconds).toFloat() / totalSeconds.toFloat()

    val canStart: Boolean get() = remainingSeconds > 0 || isRunning
}

@HiltViewModel
class FocusViewModel @Inject constructor(
    private val focusRepository: FocusRepository,
    settingsRepository: SettingsRepository,
    private val notificationHelper: NotificationHelper
) : ViewModel() {

    private val _state = MutableStateFlow(FocusUiState())
    val state: StateFlow<FocusUiState> = _state.asStateFlow()

    private var timerJob: Job? = null

    init {
        viewModelScope.launch {
            val settings = settingsRepository.settings.first()
            _state.update {
                it.copy(
                    workMinutes = settings.defaultFocusMinutes,
                    shortBreakMinutes = settings.shortBreakMinutes,
                    longBreakMinutes = settings.longBreakMinutes,
                    totalSeconds = settings.defaultFocusMinutes * 60,
                    remainingSeconds = settings.defaultFocusMinutes * 60
                )
            }
            observeStats()
        }
    }

    private fun observeStats() {
        val today = DateUtils.todayEpochDay()
        val start = DateUtils.startOfDayMillis(today)
        val end = DateUtils.endOfDayMillis(today)
        viewModelScope.launch {
            focusRepository.observeMinutesBetween(start, end).collect { minutes ->
                _state.update { it.copy(minutesToday = minutes) }
            }
        }
        viewModelScope.launch {
            focusRepository.observeBetween(start, end).collect { sessions ->
                _state.update { it.copy(sessionsToday = sessions.count { s -> s.completed }) }
            }
        }
    }

    fun start() {
        if (_state.value.isRunning) return
        _state.update { it.copy(isRunning = true) }
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                val current = _state.value
                if (current.remainingSeconds <= 1) {
                    _state.update { it.copy(remainingSeconds = 0, isRunning = false) }
                    onSessionComplete()
                    break
                }
                _state.update { it.copy(remainingSeconds = it.remainingSeconds - 1) }
            }
        }
    }

    fun pause() {
        timerJob?.cancel()
        timerJob = null
        _state.update { it.copy(isRunning = false) }
    }

    fun toggle() { if (_state.value.isRunning) pause() else start() }

    fun reset() {
        pause()
        _state.update { it.copy(remainingSeconds = it.totalSeconds) }
    }

    fun skip() {
        pause()
        advanceMode()
    }

    fun selectMode(mode: FocusMode) {
        pause()
        val minutes = minutesFor(mode)
        _state.update {
            it.copy(mode = mode, totalSeconds = minutes * 60, remainingSeconds = minutes * 60)
        }
    }

    private fun minutesFor(mode: FocusMode): Int = when (mode) {
        FocusMode.WORK -> _state.value.workMinutes
        FocusMode.SHORT_BREAK -> _state.value.shortBreakMinutes
        FocusMode.LONG_BREAK -> _state.value.longBreakMinutes
    }

    private fun onSessionComplete() {
        val current = _state.value
        if (current.mode == FocusMode.WORK) {
            viewModelScope.launch {
                focusRepository.logSession(
                    FocusSessionEntity(
                        durationMinutes = current.workMinutes,
                        tag = "Focus",
                        completed = true
                    )
                )
            }
            notificationHelper.showFocusComplete(current.workMinutes)
            _state.update { it.copy(completedInCycle = it.completedInCycle + 1) }
        }
        advanceMode()
    }

    private fun advanceMode() {
        val current = _state.value
        val nextMode = when (current.mode) {
            FocusMode.WORK ->
                if ((current.completedInCycle + 1) % 4 == 0) FocusMode.LONG_BREAK else FocusMode.SHORT_BREAK
            else -> FocusMode.WORK
        }
        val minutes = when (nextMode) {
            FocusMode.WORK -> current.workMinutes
            FocusMode.SHORT_BREAK -> current.shortBreakMinutes
            FocusMode.LONG_BREAK -> current.longBreakMinutes
        }
        _state.update {
            it.copy(mode = nextMode, totalSeconds = minutes * 60, remainingSeconds = minutes * 60, isRunning = false)
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
