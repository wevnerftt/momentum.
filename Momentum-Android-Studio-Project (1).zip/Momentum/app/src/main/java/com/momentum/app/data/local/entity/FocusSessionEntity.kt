package com.momentum.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "focus_sessions")
@Serializable
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAt: Long = System.currentTimeMillis(),
    val durationMinutes: Int,
    val tag: String? = null,
    val completed: Boolean = true,
    val distractionCount: Int = 0
)
