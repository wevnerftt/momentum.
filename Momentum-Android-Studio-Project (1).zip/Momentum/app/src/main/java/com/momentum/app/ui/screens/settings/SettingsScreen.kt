package com.momentum.app.ui.screens.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumPrimaryButton
import com.momentum.app.ui.components.MomentumSecondaryButton
import com.momentum.app.ui.components.MomentumTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let(viewModel::exportData) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(viewModel::importData) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MomentumCard {
                Column {
                    Text("Profile", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    MomentumTextField(
                        value = state.userName,
                        onValueChange = viewModel::setUserName,
                        label = "Display name"
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Appearance", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0 to "Light", 1 to "Dark", 2 to "System").forEach { (value, label) ->
                            FilterChip(
                                selected = state.themeMode == value,
                                onClick = { viewModel.setThemeMode(value) },
                                label = { Text(label) }
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    SettingSwitch(
                        title = "Dynamic colour",
                        subtitle = "Match the system Material You palette",
                        checked = state.dynamicColor,
                        onCheckedChange = viewModel::setDynamicColor
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Focus", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    SliderRow(
                        label = "Focus length: ${state.defaultFocusMinutes} min",
                        value = state.defaultFocusMinutes.toFloat(),
                        range = 5f..90f,
                        onValueChange = { viewModel.setFocusMinutes(it.toInt()) }
                    )
                    SliderRow(
                        label = "Short break: ${state.shortBreakMinutes} min",
                        value = state.shortBreakMinutes.toFloat(),
                        range = 1f..30f,
                        onValueChange = { viewModel.setShortBreak(it.toInt()) }
                    )
                    SliderRow(
                        label = "Long break: ${state.longBreakMinutes} min",
                        value = state.longBreakMinutes.toFloat(),
                        range = 5f..60f,
                        onValueChange = { viewModel.setLongBreak(it.toInt()) }
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Habits & reminders", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    SliderRow(
                        label = "Daily habit goal: ${state.dailyHabitGoal}",
                        value = state.dailyHabitGoal.toFloat(),
                        range = 1f..20f,
                        onValueChange = { viewModel.setDailyGoal(it.toInt()) }
                    )
                    SettingSwitch(
                        title = "Reminders",
                        subtitle = "Nudges at each habit's set time",
                        checked = state.remindersEnabled,
                        onCheckedChange = viewModel::setReminders
                    )
                    SettingSwitch(
                        title = "Daily digest",
                        subtitle = "A morning summary of your day",
                        checked = state.dailyDigestEnabled,
                        onCheckedChange = viewModel::setDailyDigest
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Momentum Coach", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    SettingSwitch(
                        title = "On-device coach",
                        subtitle = "Personalised, private tips computed locally",
                        checked = state.aiCoachEnabled,
                        onCheckedChange = viewModel::setAiCoach
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Backup & restore", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Export a JSON backup of all your data, or restore from a previous backup.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    MomentumPrimaryButton(
                        text = "Export data",
                        onClick = { exportLauncher.launch("momentum-backup.json") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    MomentumSecondaryButton(
                        text = "Import data",
                        onClick = { importLauncher.launch(arrayOf("application/json")) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    state.statusMessage?.let { message ->
                        Spacer(Modifier.height(10.dp))
                        Text(
                            message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            MomentumCard {
                Column {
                    Text("About", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Momentum 1.0.0 — habits, tasks, focus and insights in one calm space.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onValueChange, valueRange = range)
    }
}
