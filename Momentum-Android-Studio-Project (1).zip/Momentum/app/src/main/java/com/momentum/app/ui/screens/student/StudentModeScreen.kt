package com.momentum.app.ui.screens.student

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.util.DateUtils
import com.momentum.app.core.util.Formatters
import com.momentum.app.domain.study.StudyPlanner
import com.momentum.app.ui.components.EmptyState
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumPrimaryButton
import com.momentum.app.ui.components.Pill
import com.momentum.app.ui.components.SectionHeader
import com.momentum.app.ui.theme.colorFromHex

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentModeScreen(
    onAddSubject: () -> Unit,
    onEditSubject: (Long) -> Unit,
    onBack: () -> Unit,
    viewModel: StudyPlannerViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Student Mode") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddSubject,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Subject") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.isEmpty) {
                item {
                    EmptyState(
                        icon = Icons.Filled.School,
                        title = "No subjects yet",
                        subtitle = "Add your subjects with exam dates and Momentum will build a study plan."
                    )
                }
            } else {
                item {
                    MomentumCard {
                        Column {
                            Text(
                                "Daily study budget: ${Formatters.hoursMinutes(state.dailyBudgetMinutes)}",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Slider(
                                value = state.dailyBudgetMinutes.toFloat(),
                                onValueChange = { viewModel.setBudget(it.toInt()) },
                                valueRange = 30f..360f
                            )
                            MomentumPrimaryButton(
                                text = if (state.createdTasks > 0)
                                    "Added ${state.createdTasks} study tasks"
                                else "Turn plan into tasks",
                                icon = Icons.Filled.AutoAwesome,
                                onClick = viewModel::generateTasksFromPlan,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                item { SectionHeader(title = "Subjects") }
                items(state.subjects, key = { it.id }) { subject ->
                    val daysLeft = StudyPlanner.daysUntilExam(subject)
                    MomentumCard(onClick = { onEditSubject(subject.id) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(subject.name, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Pill(
                                        text = when (daysLeft) {
                                            null -> "No exam date"
                                            0L -> "Exam today"
                                            else -> "$daysLeft days to exam"
                                        },
                                        color = colorFromHex(subject.colorHex)
                                    )
                                    Pill(
                                        text = "Target ${subject.targetHours}h",
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }
                    }
                }

                item { SectionHeader(title = "Next 7 days") }
                val grouped = state.plan.groupBy { it.epochDay }.toSortedMap()
                grouped.forEach { (day, blocks) ->
                    item(key = "day-$day") {
                        MomentumCard {
                            Column {
                                Text(
                                    if (day == DateUtils.todayEpochDay()) "Today"
                                    else DateUtils.formatDateFull(DateUtils.startOfDayMillis(day)),
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Spacer(Modifier.height(8.dp))
                                blocks.forEach { block ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Pill(
                                            text = "${block.minutes}m",
                                            color = colorFromHex(block.colorHex)
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            "  ${block.subjectName}",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                    Spacer(Modifier.height(6.dp))
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(88.dp)) }
        }
    }
}
