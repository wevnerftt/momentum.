package com.momentum.app.ui.screens.student

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.SubjectEntity
import com.momentum.app.data.local.entity.TaskEntity
import com.momentum.app.data.repository.SettingsRepository
import com.momentum.app.data.repository.SubjectRepository
import com.momentum.app.data.repository.TaskRepository
import com.momentum.app.domain.study.StudyBlock
import com.momentum.app.domain.study.StudyPlanner
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StudentUiState(
    val subjects: List<SubjectEntity> = emptyList(),
    val plan: List<StudyBlock> = emptyList(),
    val dailyBudgetMinutes: Int = 120,
    val createdTasks: Int = 0
) {
    val isEmpty: Boolean get() = subjects.isEmpty()

    fun planForDay(epochDay: Long): List<StudyBlock> = plan.filter { it.epochDay == epochDay }
}

@HiltViewModel
class StudyPlannerViewModel @Inject constructor(
    private val subjectRepository: SubjectRepository,
    private val taskRepository: TaskRepository,
    settingsRepository: SettingsRepository
) : ViewModel() {

    private val budget = MutableStateFlow(120)
    private val createdTasks = MutableStateFlow(0)

    val state: StateFlow<StudentUiState> = combine(
        subjectRepository.observeAll(),
        budget,
        createdTasks
    ) { subjects, budgetMinutes, created ->
        StudentUiState(
            subjects = subjects,
            plan = StudyPlanner.plan(subjects, budgetMinutes),
            dailyBudgetMinutes = budgetMinutes,
            createdTasks = created
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StudentUiState())

    fun setBudget(minutes: Int) { budget.value = minutes.coerceIn(30, 480) }

    fun deleteSubject(subject: SubjectEntity) {
        viewModelScope.launch { subjectRepository.delete(subject) }
    }

    /** Turns the next 3 days of the plan into concrete tasks. */
    fun generateTasksFromPlan() {
        viewModelScope.launch {
            val upcoming = state.value.plan
                .filter { it.epochDay <= DateUtils.todayEpochDay() + 2 }
            upcoming.forEach { block ->
                taskRepository.upsert(
                    TaskEntity(
                        title = "Study ${block.subjectName}",
                        description = "${block.minutes} minute focused block",
                        dueDate = DateUtils.startOfDayMillis(block.epochDay),
                        priority = com.momentum.app.core.Constants.PRIORITY_MEDIUM,
                        subjectId = block.subjectId,
                        estimatedMinutes = block.minutes
                    )
                )
            }
            createdTasks.value = upcoming.size
        }
    }
}
