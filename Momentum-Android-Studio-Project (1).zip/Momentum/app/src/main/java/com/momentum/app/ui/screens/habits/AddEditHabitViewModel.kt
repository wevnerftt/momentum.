package com.momentum.app.ui.screens.habits

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.Constants
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.data.repository.HabitRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HabitFormState(
    val id: Long = 0,
    val name: String = "",
    val description: String = "",
    val icon: String = "CheckCircle",
    val colorHex: String = "#10B981",
    val frequency: String = Constants.FREQ_DAILY,
    val customDays: Set<Int> = emptySet(),
    val isQuantity: Boolean = false,
    val targetQuantity: String = "8",
    val targetUnit: String = "times",
    val isTimeBased: Boolean = false,
    val targetDurationMinutes: String = "30",
    val reminderTime: String? = null,
    val isEditing: Boolean = false,
    val saved: Boolean = false
) {
    val isValid: Boolean
        get() = name.isNotBlank() &&
            (frequency != Constants.FREQ_CUSTOM || customDays.isNotEmpty())
}

@HiltViewModel
class AddEditHabitViewModel @Inject constructor(
    private val habitRepository: HabitRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val habitId: Long = savedStateHandle.get<Long>("habitId") ?: -1L

    private val _state = MutableStateFlow(HabitFormState())
    val state: StateFlow<HabitFormState> = _state.asStateFlow()

    init {
        if (habitId > 0) load(habitId)
    }

    private fun load(id: Long) {
        viewModelScope.launch {
            val habit = habitRepository.getHabit(id) ?: return@launch
            _state.update {
                HabitFormState(
                    id = habit.id,
                    name = habit.name,
                    description = habit.description.orEmpty(),
                    icon = habit.icon,
                    colorHex = habit.colorHex,
                    frequency = habit.frequency,
                    customDays = habit.customDays?.split(",")
                        ?.mapNotNull { d -> d.trim().toIntOrNull() }?.toSet().orEmpty(),
                    isQuantity = (habit.targetQuantity ?: 1) > 1,
                    targetQuantity = (habit.targetQuantity ?: 8).toString(),
                    targetUnit = habit.targetUnit ?: "times",
                    isTimeBased = habit.isTimeBased,
                    targetDurationMinutes = (habit.targetDurationMinutes ?: 30).toString(),
                    reminderTime = habit.reminderTime,
                    isEditing = true
                )
            }
        }
    }

    fun setName(v: String) = _state.update { it.copy(name = v) }
    fun setDescription(v: String) = _state.update { it.copy(description = v) }
    fun setIcon(v: String) = _state.update { it.copy(icon = v) }
    fun setColor(v: String) = _state.update { it.copy(colorHex = v) }
    fun setFrequency(v: String) = _state.update { it.copy(frequency = v) }
    fun setQuantityEnabled(v: Boolean) = _state.update { it.copy(isQuantity = v) }
    fun setQuantity(v: String) = _state.update { it.copy(targetQuantity = v.filter { c -> c.isDigit() }) }
    fun setUnit(v: String) = _state.update { it.copy(targetUnit = v) }
    fun setTimeBased(v: Boolean) = _state.update { it.copy(isTimeBased = v) }
    fun setDuration(v: String) = _state.update { it.copy(targetDurationMinutes = v.filter { c -> c.isDigit() }) }
    fun setReminder(v: String?) = _state.update { it.copy(reminderTime = if (it.reminderTime == v) null else v) }

    fun toggleCustomDay(day: Int) = _state.update {
        val days = it.customDays.toMutableSet()
        if (!days.add(day)) days.remove(day)
        it.copy(customDays = days)
    }

    fun save() {
        val s = _state.value
        if (!s.isValid) return
        viewModelScope.launch {
            val habit = HabitEntity(
                id = s.id,
                name = s.name.trim(),
                description = s.description.trim().ifBlank { null },
                icon = s.icon,
                colorHex = s.colorHex,
                frequency = s.frequency,
                customDays = if (s.frequency == Constants.FREQ_CUSTOM)
                    s.customDays.sorted().joinToString(",") else null,
                targetQuantity = if (s.isQuantity) s.targetQuantity.toIntOrNull() ?: 1 else null,
                targetUnit = if (s.isQuantity) s.targetUnit.ifBlank { "times" } else null,
                isTimeBased = s.isTimeBased,
                targetDurationMinutes = if (s.isTimeBased) s.targetDurationMinutes.toIntOrNull() else null,
                reminderTime = s.reminderTime
            )
            habitRepository.upsertHabit(habit)
            _state.update { it.copy(saved = true) }
        }
    }

    fun delete() {
        val id = _state.value.id
        if (id <= 0) return
        viewModelScope.launch {
            habitRepository.getHabit(id)?.let { habitRepository.deleteHabit(it) }
            _state.update { it.copy(saved = true) }
        }
    }
}
