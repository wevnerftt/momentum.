package com.momentum.app.ui.screens.goals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.data.local.entity.GoalEntity
import com.momentum.app.data.repository.GoalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class GoalsUiState(
    val goals: List<GoalEntity> = emptyList()
) {
    val isEmpty: Boolean get() = goals.isEmpty()
}

@HiltViewModel
class GoalsViewModel @Inject constructor(
    private val goalRepository: GoalRepository
) : ViewModel() {

    val state: StateFlow<GoalsUiState> = goalRepository.observeActive()
        .map { GoalsUiState(goals = it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GoalsUiState())

    fun setProgress(id: Long, progress: Float) {
        viewModelScope.launch { goalRepository.setProgress(id, progress) }
    }

    fun delete(goal: GoalEntity) {
        viewModelScope.launch { goalRepository.delete(goal) }
    }
}
