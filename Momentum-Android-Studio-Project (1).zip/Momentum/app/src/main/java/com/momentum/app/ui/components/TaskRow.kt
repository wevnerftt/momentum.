package com.momentum.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.momentum.app.core.Constants
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.TaskEntity

@Composable
fun TaskRow(
    task: TaskEntity,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val overdue = !task.isCompleted && DateUtils.isOverdue(task.dueDate)
    val accent = when {
        task.isCompleted -> MaterialTheme.colorScheme.outline
        overdue -> MaterialTheme.colorScheme.error
        task.priority == Constants.PRIORITY_HIGH -> MaterialTheme.colorScheme.error
        task.priority == Constants.PRIORITY_MEDIUM -> MaterialTheme.colorScheme.tertiary
        else -> MaterialTheme.colorScheme.secondary
    }

    MomentumCard(modifier = modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val boxColor by animateColorAsState(
                targetValue = if (task.isCompleted) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant,
                label = "taskBox"
            )
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(boxColor)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (task.isCompleted) {
                    Icon(Icons.Filled.Check, contentDescription = "Complete", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null
                )
                if (!task.description.isNullOrBlank()) {
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                if (task.dueDate != null || task.priority == Constants.PRIORITY_HIGH) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (task.dueDate != null) {
                            Pill(
                                text = if (overdue) "Overdue" else DateUtils.formatDateFull(task.dueDate),
                                color = accent,
                                icon = Icons.Filled.Event
                            )
                        }
                        if (task.priority == Constants.PRIORITY_HIGH && !task.isCompleted) {
                            Pill(text = "High", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}
