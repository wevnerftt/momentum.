package com.momentum.app.data.repository

import com.momentum.app.data.local.dao.FocusSessionDao
import com.momentum.app.data.local.entity.FocusSessionEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FocusRepository @Inject constructor(
    private val focusSessionDao: FocusSessionDao
) {
    fun observeAll(): Flow<List<FocusSessionEntity>> = focusSessionDao.observeAll()
    fun observeBetween(from: Long, to: Long): Flow<List<FocusSessionEntity>> =
        focusSessionDao.observeBetween(from, to)
    fun observeMinutesBetween(from: Long, to: Long): Flow<Int> =
        focusSessionDao.observeMinutesBetween(from, to)
    fun observeTotalMinutes(): Flow<Int> = focusSessionDao.observeTotalMinutes()
    fun observeSessionCount(): Flow<Int> = focusSessionDao.observeSessionCount()

    suspend fun logSession(session: FocusSessionEntity): Long = focusSessionDao.insert(session)
}
