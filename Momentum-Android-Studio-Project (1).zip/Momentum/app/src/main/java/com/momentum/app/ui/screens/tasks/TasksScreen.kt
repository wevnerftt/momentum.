package com.momentum.app.ui.screens.tasks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.data.local.entity.TaskEntity
import com.momentum.app.ui.components.EmptyState
import com.momentum.app.ui.components.SectionHeader
import com.momentum.app.ui.components.TaskRow

@Composable
fun TasksScreen(
    onAddTask: () -> Unit,
    onEditTask: (Long) -> Unit,
    viewModel: TasksViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf(TaskFilter.ACTIVE) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddTask,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("New task") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Tasks",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TaskFilter.entries.forEach { option ->
                        FilterChip(
                            selected = filter == option,
                            onClick = { filter = option; viewModel.setFilter(option) },
                            label = {
                                Text(
                                    when (option) {
                                        TaskFilter.ACTIVE -> "Active"
                                        TaskFilter.COMPLETED -> "Completed"
                                        TaskFilter.ALL -> "All"
                                    }
                                )
                            }
                        )
                    }
                }
            }

            if (state.isEmpty) {
                item {
                    EmptyState(
                        icon = Icons.Filled.FormatListBulleted,
                        title = "You are all caught up",
                        subtitle = "Add a task to plan what is next."
                    )
                }
            } else {
                if (filter != TaskFilter.COMPLETED) {
                    taskSection("Overdue", state.overdue, onEditTask, viewModel::toggle)
                    taskSection("Today", state.today, onEditTask, viewModel::toggle)
                    taskSection("Upcoming", state.upcoming, onEditTask, viewModel::toggle)
                    taskSection("No date", state.noDate, onEditTask, viewModel::toggle)
                }
                if (filter != TaskFilter.ACTIVE) {
                    taskSection("Completed", state.completed, onEditTask, viewModel::toggle)
                }
            }

            item { Spacer(Modifier.height(88.dp)) }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.taskSection(
    title: String,
    tasks: List<TaskEntity>,
    onEdit: (Long) -> Unit,
    onToggle: (Long) -> Unit
) {
    if (tasks.isEmpty()) return
    item(key = "header-$title") {
        SectionHeader(title = title)
    }
    items(tasks, key = { "$title-${it.id}" }) { task ->
        TaskRow(
            task = task,
            onToggle = { onToggle(task.id) },
            onClick = { onEdit(task.id) }
        )
    }
}
