package com.momentum.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.momentum.app.data.local.entity.JournalEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface JournalDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: JournalEntity): Long

    @Update
    suspend fun update(entry: JournalEntity)

    @Delete
    suspend fun delete(entry: JournalEntity)

    @Query("SELECT * FROM journal ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<JournalEntity>>

    @Query("SELECT * FROM journal WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun search(query: String): Flow<List<JournalEntity>>

    @Query("SELECT * FROM journal WHERE id = :id LIMIT 1")
    fun observeById(id: Long): Flow<JournalEntity?>

    @Query("SELECT AVG(mood) FROM journal WHERE mood > 0")
    fun observeAverageMood(): Flow<Float?>

    @Query("SELECT * FROM journal")
    suspend fun getAllOnce(): List<JournalEntity>

    @Query("DELETE FROM journal")
    suspend fun deleteAll()
}
