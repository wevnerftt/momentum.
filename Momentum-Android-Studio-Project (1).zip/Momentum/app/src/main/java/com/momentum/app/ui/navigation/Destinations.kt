package com.momentum.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Today
import androidx.compose.ui.graphics.vector.ImageVector

object Routes {
    const val ONBOARDING = "onboarding"
    const val TODAY = "today"
    const val HABITS = "habits"
    const val TASKS = "tasks"
    const val FOCUS = "focus"
    const val INSIGHTS = "insights"
    const val GOALS = "goals"
    const val STUDENT = "student"
    const val JOURNAL = "journal"
    const val SETTINGS = "settings"

    const val HABIT_EDIT = "habit_edit"
    const val TASK_EDIT = "task_edit"
    const val GOAL_EDIT = "goal_edit"
    const val SUBJECT_EDIT = "subject_edit"
    const val JOURNAL_EDIT = "journal_edit"

    fun habitEdit(habitId: Long = -1L) = "$HABIT_EDIT?habitId=$habitId"
    fun taskEdit(taskId: Long = -1L) = "$TASK_EDIT?taskId=$taskId"
    fun goalEdit(goalId: Long = -1L) = "$GOAL_EDIT?goalId=$goalId"
    fun subjectEdit(subjectId: Long = -1L) = "$SUBJECT_EDIT?subjectId=$subjectId"
    fun journalEdit(entryId: Long = -1L) = "$JOURNAL_EDIT?entryId=$entryId"
}

val bottomRoutes = setOf(
    Routes.TODAY, Routes.HABITS, Routes.TASKS, Routes.FOCUS, Routes.INSIGHTS
)

data class BottomNavItem(
    val title: String,
    val icon: ImageVector,
    val route: String
)

val bottomNavItems = listOf(
    BottomNavItem("Today", Icons.Filled.Today, Routes.TODAY),
    BottomNavItem("Habits", Icons.Filled.CheckCircle, Routes.HABITS),
    BottomNavItem("Tasks", Icons.Filled.FormatListBulleted, Routes.TASKS),
    BottomNavItem("Focus", Icons.Filled.Timer, Routes.FOCUS),
    BottomNavItem("Insights", Icons.Filled.BarChart, Routes.INSIGHTS)
)
