package com.momentum.app.ui.screens.habits

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.ui.components.EmptyState
import com.momentum.app.ui.components.HabitRow
import com.momentum.app.ui.components.SectionHeader
import com.momentum.app.ui.theme.colorFromHex
import com.momentum.app.ui.util.IconMapper
import java.time.LocalDate

@Composable
fun HabitsScreen(
    onAddHabit: () -> Unit,
    onEditHabit: (Long) -> Unit,
    viewModel: HabitsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddHabit,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("New habit") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Habits",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            item { WeekStrip(state, viewModel::selectDay) }

            if (state.habits.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Filled.CheckCircle,
                        title = "No habits yet",
                        subtitle = "Tap “New habit” to add the first one to your routine."
                    )
                }
            } else {
                items(state.habits, key = { it.id }) { habit ->
                    HabitRow(
                        name = habit.name,
                        icon = IconMapper.iconFor(habit.icon),
                        color = colorFromHex(habit.colorHex),
                        subtitle = subtitle(habit, state.weeklyCounts[habit.id] ?: 0),
                        isCompleted = state.completedOnSelected.contains(habit.id),
                        onToggle = { viewModel.toggleHabit(habit.id) },
                        onClick = { onEditHabit(habit.id) }
                    )
                }
            }

            item { Spacer(Modifier.height(88.dp)) }
        }
    }
}

private fun subtitle(habit: HabitEntity, weekCount: Int): String {
    val qty = habit.targetQuantity
    return when {
        qty != null && qty > 1 -> "Target ${qty} ${habit.targetUnit ?: ""} · $weekCount this week".trim()
        habit.targetDurationMinutes != null -> "${habit.targetDurationMinutes} min · $weekCount this week"
        else -> "$weekCount this week"
    }
}

@Composable
private fun WeekStrip(state: HabitsUiState, onSelect: (Long) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        state.weekDays.forEach { day ->
            val selected = day == state.selectedDay
            val isToday = day == DateUtils.todayEpochDay()
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(MaterialTheme.shapes.medium)
                    .background(
                        if (selected) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                    )
                    .clickable { onSelect(day) }
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    DateUtils.formatEpochDayShort(day).take(1),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    LocalDate.ofEpochDay(day).dayOfMonth.toString(),
                    style = MaterialTheme.typography.titleSmall,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(
                            if (isToday) MaterialTheme.colorScheme.tertiary
                            else androidx.compose.ui.graphics.Color.Transparent
                        )
                )
            }
        }
    }
}
