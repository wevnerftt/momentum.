package com.momentum.app.ui.screens.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.Constants
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.data.repository.CategoryRepository
import com.momentum.app.data.repository.HabitRepository
import com.momentum.app.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class OnboardingUiState(
    val name: String = "",
    val selectedFocus: Set<String> = emptySet(),
    val reminderTime: String = "08:00"
) {
    val canContinueName: Boolean get() = name.isNotBlank()
}

private val defaultHabitsByFocus = mapOf(
    "Health" to HabitEntity(name = "Drink water", icon = "LocalDrink", colorHex = "#0EA5E9",
        targetQuantity = 8, targetUnit = "glasses"),
    "Fitness" to HabitEntity(name = "Move your body", icon = "DirectionsRun", colorHex = "#F43F5E",
        targetDurationMinutes = 30, isTimeBased = true),
    "Study" to HabitEntity(name = "Deep study block", icon = "School", colorHex = "#F59E0B",
        targetDurationMinutes = 60, isTimeBased = true),
    "Mind" to HabitEntity(name = "Meditate", icon = "SelfImprovement", colorHex = "#6366F1",
        targetDurationMinutes = 10, isTimeBased = true),
    "Work" to HabitEntity(name = "Plan the day", icon = "Work", colorHex = "#8B5CF6")
)

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val habitRepository: HabitRepository,
    private val categoryRepository: CategoryRepository
) : ViewModel() {

    private val _state = MutableStateFlow(OnboardingUiState())
    val state: StateFlow<OnboardingUiState> = _state.asStateFlow()

    fun setName(value: String) { _state.value = _state.value.copy(name = value) }

    fun toggleFocus(value: String) {
        val current = _state.value.selectedFocus.toMutableSet()
        if (!current.add(value)) current.remove(value)
        _state.value = _state.value.copy(selectedFocus = current)
    }

    fun setReminderTime(value: String) { _state.value = _state.value.copy(reminderTime = value) }

    fun finish(onDone: () -> Unit) {
        val snapshot = _state.value
        viewModelScope.launch {
            settingsRepository.setUserName(snapshot.name.trim())
            settingsRepository.setRemindersEnabled(true)
            categoryRepository.seedDefaultsIfEmpty()

            val chosen = if (snapshot.selectedFocus.isEmpty())
                listOf("Health", "Mind") else snapshot.selectedFocus.toList()

            chosen.mapNotNull { defaultHabitsByFocus[it] }.forEach { habit ->
                habitRepository.upsertHabit(
                    habit.copy(
                        frequency = Constants.FREQ_DAILY,
                        reminderTime = snapshot.reminderTime
                    )
                )
            }
            settingsRepository.setOnboardingComplete(true)
            onDone()
        }
    }
}
