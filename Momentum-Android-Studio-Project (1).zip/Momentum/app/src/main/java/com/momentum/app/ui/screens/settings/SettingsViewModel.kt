package com.momentum.app.ui.screens.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.data.backup.DataBackupManager
import com.momentum.app.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val userName: String = "",
    val themeMode: Int = 2,
    val dynamicColor: Boolean = true,
    val remindersEnabled: Boolean = true,
    val dailyDigestEnabled: Boolean = true,
    val defaultFocusMinutes: Int = 25,
    val shortBreakMinutes: Int = 5,
    val longBreakMinutes: Int = 15,
    val dailyHabitGoal: Int = 5,
    val aiCoachEnabled: Boolean = true,
    val statusMessage: String? = null
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val backupManager: DataBackupManager
) : ViewModel() {

    private val status = MutableStateFlow<String?>(null)

    val state: StateFlow<SettingsUiState> = combine(
        settingsRepository.settings,
        status
    ) { settings, message ->
        SettingsUiState(
            userName = settings.userName,
            themeMode = settings.themeMode,
            dynamicColor = settings.dynamicColor,
            remindersEnabled = settings.remindersEnabled,
            dailyDigestEnabled = settings.dailyDigestEnabled,
            defaultFocusMinutes = settings.defaultFocusMinutes,
            shortBreakMinutes = settings.shortBreakMinutes,
            longBreakMinutes = settings.longBreakMinutes,
            dailyHabitGoal = settings.dailyHabitGoal,
            aiCoachEnabled = settings.aiCoachEnabled,
            statusMessage = message
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun setUserName(v: String) = launch { settingsRepository.setUserName(v) }
    fun setThemeMode(v: Int) = launch { settingsRepository.setThemeMode(v) }
    fun setDynamicColor(v: Boolean) = launch { settingsRepository.setDynamicColor(v) }
    fun setReminders(v: Boolean) = launch { settingsRepository.setRemindersEnabled(v) }
    fun setDailyDigest(v: Boolean) = launch { settingsRepository.setDailyDigestEnabled(v) }
    fun setFocusMinutes(v: Int) = launch { settingsRepository.setDefaultFocusMinutes(v.coerceIn(5, 90)) }
    fun setShortBreak(v: Int) = launch { settingsRepository.setShortBreakMinutes(v.coerceIn(1, 30)) }
    fun setLongBreak(v: Int) = launch { settingsRepository.setLongBreakMinutes(v.coerceIn(5, 60)) }
    fun setDailyGoal(v: Int) = launch { settingsRepository.setDailyHabitGoal(v.coerceIn(1, 20)) }
    fun setAiCoach(v: Boolean) = launch { settingsRepository.setAiCoachEnabled(v) }

    fun exportData(uri: Uri) {
        viewModelScope.launch {
            backupManager.exportTo(uri)
                .onSuccess { status.value = "Exported $it records." }
                .onFailure { status.value = "Export failed: ${it.message ?: "unknown error"}" }
        }
    }

    fun importData(uri: Uri) {
        viewModelScope.launch {
            backupManager.importFrom(uri)
                .onSuccess { status.value = "Imported $it records." }
                .onFailure { status.value = "Import failed: ${it.message ?: "unknown error"}" }
        }
    }

    fun clearStatus() { status.value = null }

    private fun launch(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }
}
