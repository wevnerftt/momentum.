package com.momentum.app.ui.screens.goals

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.Constants
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.GoalEntity
import com.momentum.app.data.repository.GoalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class GoalFormState(
    val id: Long = 0,
    val title: String = "",
    val description: String = "",
    val category: String = Constants.GOAL_PERSONAL,
    val targetDate: Long? = null,
    val progress: Float = 0f,
    val isEditing: Boolean = false,
    val saved: Boolean = false
) {
    val isValid: Boolean get() = title.isNotBlank()
}

@HiltViewModel
class AddEditGoalViewModel @Inject constructor(
    private val goalRepository: GoalRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val goalId: Long = savedStateHandle.get<Long>("goalId") ?: -1L

    private val _state = MutableStateFlow(GoalFormState())
    val state: StateFlow<GoalFormState> = _state.asStateFlow()

    init { if (goalId > 0) load(goalId) }

    private fun load(id: Long) {
        viewModelScope.launch {
            val goal = goalRepository.observeById(id).first() ?: return@launch
            _state.update {
                GoalFormState(
                    id = goal.id,
                    title = goal.title,
                    description = goal.description.orEmpty(),
                    category = goal.category,
                    targetDate = goal.targetDate,
                    progress = goal.progress,
                    isEditing = true
                )
            }
        }
    }

    fun setTitle(v: String) = _state.update { it.copy(title = v) }
    fun setDescription(v: String) = _state.update { it.copy(description = v) }
    fun setCategory(v: String) = _state.update { it.copy(category = v) }
    fun setProgress(v: Float) = _state.update { it.copy(progress = v.coerceIn(0f, 1f)) }
    fun setTargetInDays(days: Long?) = _state.update {
        it.copy(targetDate = days?.let { d -> DateUtils.millisOf(java.time.LocalDate.now().plusDays(d)) })
    }

    fun save() {
        val s = _state.value
        if (!s.isValid) return
        viewModelScope.launch {
            goalRepository.upsert(
                GoalEntity(
                    id = s.id,
                    title = s.title.trim(),
                    description = s.description.trim().ifBlank { null },
                    category = s.category,
                    targetDate = s.targetDate,
                    progress = s.progress
                )
            )
            _state.update { it.copy(saved = true) }
        }
    }

    fun delete() {
        val id = _state.value.id
        if (id <= 0) return
        viewModelScope.launch {
            goalRepository.observeById(id).first()?.let { goalRepository.delete(it) }
            _state.update { it.copy(saved = true) }
        }
    }
}
