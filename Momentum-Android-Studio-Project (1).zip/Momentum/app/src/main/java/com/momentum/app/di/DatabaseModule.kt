package com.momentum.app.di

import android.content.Context
import com.momentum.app.data.local.MomentumDatabase
import com.momentum.app.data.local.dao.CategoryDao
import com.momentum.app.data.local.dao.FocusSessionDao
import com.momentum.app.data.local.dao.GoalDao
import com.momentum.app.data.local.dao.HabitDao
import com.momentum.app.data.local.dao.HabitLogDao
import com.momentum.app.data.local.dao.JournalDao
import com.momentum.app.data.local.dao.SubjectDao
import com.momentum.app.data.local.dao.TaskDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MomentumDatabase =
        MomentumDatabase.create(context)

    @Provides fun provideHabitDao(db: MomentumDatabase): HabitDao = db.habitDao()
    @Provides fun provideHabitLogDao(db: MomentumDatabase): HabitLogDao = db.habitLogDao()
    @Provides fun provideTaskDao(db: MomentumDatabase): TaskDao = db.taskDao()
    @Provides fun provideGoalDao(db: MomentumDatabase): GoalDao = db.goalDao()
    @Provides fun provideSubjectDao(db: MomentumDatabase): SubjectDao = db.subjectDao()
    @Provides fun provideJournalDao(db: MomentumDatabase): JournalDao = db.journalDao()
    @Provides fun provideFocusSessionDao(db: MomentumDatabase): FocusSessionDao = db.focusSessionDao()
    @Provides fun provideCategoryDao(db: MomentumDatabase): CategoryDao = db.categoryDao()
}
