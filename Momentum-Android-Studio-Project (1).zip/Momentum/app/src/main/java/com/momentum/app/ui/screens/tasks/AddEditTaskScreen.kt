@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.momentum.app.ui.screens.tasks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.Constants
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumPrimaryButton
import com.momentum.app.ui.components.MomentumTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTaskScreen(
    onDone: () -> Unit,
    viewModel: AddEditTaskViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.saved) { if (state.saved) onDone() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEditing) "Edit task" else "New task") },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (state.isEditing) {
                        IconButton(onClick = viewModel::delete) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MomentumCard {
                Column {
                    MomentumTextField(
                        value = state.title,
                        onValueChange = viewModel::setTitle,
                        label = "Task title",
                        placeholder = "e.g. Submit assignment"
                    )
                    Spacer(Modifier.height(12.dp))
                    MomentumTextField(
                        value = state.description,
                        onValueChange = viewModel::setDescription,
                        label = "Notes (optional)",
                        singleLine = false,
                        minLines = 2
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Priority", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            Constants.PRIORITY_LOW to "Low",
                            Constants.PRIORITY_MEDIUM to "Medium",
                            Constants.PRIORITY_HIGH to "High"
                        ).forEach { (value, label) ->
                            FilterChip(
                                selected = state.priority == value,
                                onClick = { viewModel.setPriority(value) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            MomentumCard {
                Column {
                    Text("Due date", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = state.dueDate == null,
                            onClick = { viewModel.setDueInDays(null) },
                            label = { Text("None") }
                        )
                        listOf(0L to "Today", 1L to "Tomorrow", 3L to "In 3 days", 7L to "Next week")
                            .forEach { (days, label) ->
                                val target = com.momentum.app.core.util.DateUtils
                                    .millisOf(java.time.LocalDate.now().plusDays(days))
                                FilterChip(
                                    selected = state.dueDate == target,
                                    onClick = { viewModel.setDueInDays(days) },
                                    label = { Text(label) }
                                )
                            }
                    }
                    Spacer(Modifier.height(12.dp))
                    MomentumTextField(
                        value = state.estimatedMinutes,
                        onValueChange = viewModel::setEstimated,
                        label = "Estimated minutes (optional)",
                        keyboardType = KeyboardType.Number
                    )
                }
            }

            MomentumPrimaryButton(
                text = "Save task",
                onClick = viewModel::save,
                enabled = state.isValid,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
