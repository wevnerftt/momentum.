package com.momentum.app.domain.util

import com.momentum.app.core.util.DateUtils

object StreakCalculator {

    /**
     * Current consecutive-day streak of completed habit activity.
     * A missing log for today does not break the streak (the day is still in progress),
     * so the run is counted from today or yesterday backwards.
     */
    fun currentStreak(completedEpochDays: Set<Long>): Int {
        if (completedEpochDays.isEmpty()) return 0
        val today = DateUtils.todayEpochDay()
        var cursor = if (completedEpochDays.contains(today)) today else today - 1
        var streak = 0
        while (completedEpochDays.contains(cursor)) {
            streak++
            cursor--
        }
        return streak
    }

    fun longestStreak(completedEpochDays: Set<Long>): Int {
        if (completedEpochDays.isEmpty()) return 0
        val sorted = completedEpochDays.sorted()
        var best = 1
        var run = 1
        for (i in 1 until sorted.size) {
            if (sorted[i] == sorted[i - 1] + 1) {
                run++
            } else {
                run = 1
            }
            if (run > best) best = run
        }
        return best
    }
}
