@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.momentum.app.ui.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumPrimaryButton
import com.momentum.app.ui.components.MomentumTextField
import com.momentum.app.ui.components.ProgressRing
import kotlinx.coroutines.launch

private val focusOptions = listOf("Health", "Fitness", "Study", "Mind", "Work")
private val reminderOptions = listOf("06:30", "07:30", "08:00", "09:00", "12:00", "18:00", "21:00")

@Composable
fun OnboardingScreen(
    onFinished: () -> Unit,
    viewModel: OnboardingViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val pagerState = rememberPagerState(pageCount = { 3 })
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { page ->
            when (page) {
                0 -> WelcomePage()
                1 -> NamePage(state, viewModel)
                else -> FocusPage(state, viewModel)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(3) { index ->
                val selected = index == pagerState.currentPage
                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .size(if (selected) 10.dp else 8.dp)
                        .clip(CircleShape)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        MomentumPrimaryButton(
            text = if (pagerState.currentPage == 2) "Start my journey" else "Continue",
            icon = if (pagerState.currentPage == 2) null else Icons.Filled.ArrowForward,
            enabled = pagerState.currentPage != 1 || state.canContinueName,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (pagerState.currentPage < 2) {
                    scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                } else {
                    viewModel.finish(onFinished)
                }
            }
        )
    }
}

@Composable
private fun WelcomePage() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ProgressRing(progress = 0.72f, size = 132.dp, strokeWidth = 14.dp) {
            Text("M", style = MaterialTheme.typography.displayMedium)
        }
        Spacer(Modifier.height(28.dp))
        Text("Momentum", style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            "Build habits, focus deeply, and keep your goals in motion — all in one calm, fluid space.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun NamePage(state: OnboardingUiState, viewModel: OnboardingViewModel) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center
    ) {
        Text("What should we call you?", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        MomentumTextField(
            value = state.name,
            onValueChange = viewModel::setName,
            label = "Your name",
            placeholder = "e.g. Debangshu"
        )
    }
}

@Composable
private fun FocusPage(state: OnboardingUiState, viewModel: OnboardingViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("What do you want to build?", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Pick a few areas. We will seed starter habits you can edit anytime.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))
        MomentumCard {
            Column {
                Text("Focus areas", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    focusOptions.forEach { option ->
                        FilterChip(
                            selected = state.selectedFocus.contains(option),
                            onClick = { viewModel.toggleFocus(option) },
                            label = { Text(option) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            )
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        MomentumCard {
            Column {
                Text("Daily reminder time", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    reminderOptions.forEach { option ->
                        FilterChip(
                            selected = state.reminderTime == option,
                            onClick = { viewModel.setReminderTime(option) },
                            label = { Text(option) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            )
                        )
                    }
                }
            }
        }
    }
}
