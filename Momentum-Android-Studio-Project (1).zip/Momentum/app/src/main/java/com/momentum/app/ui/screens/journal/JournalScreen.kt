package com.momentum.app.ui.screens.journal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.util.DateUtils
import com.momentum.app.ui.components.EmptyState
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumTextField
import com.momentum.app.ui.components.Pill

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(
    onAddEntry: () -> Unit,
    onEditEntry: (Long) -> Unit,
    onBack: () -> Unit,
    viewModel: JournalViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Journal") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddEntry,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Write") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                MomentumTextField(
                    value = state.query,
                    onValueChange = viewModel::setQuery,
                    label = "Search entries",
                    placeholder = "Search by title or content"
                )
            }

            if (state.entries.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Filled.Book,
                        title = "Your journal is empty",
                        subtitle = "Capture a thought, a win, or a lesson from today."
                    )
                }
            } else {
                items(state.entries, key = { it.id }) { entry ->
                    MomentumCard(onClick = { onEditEntry(entry.id) }) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    entry.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                if (entry.mood > 0) {
                                    Pill(
                                        text = moodLabel(entry.mood),
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                entry.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 3
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                DateUtils.formatDateFull(entry.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(88.dp)) }
        }
    }
}

private fun moodLabel(mood: Int): String = when (mood) {
    1 -> "Rough"
    2 -> "Low"
    3 -> "Okay"
    4 -> "Good"
    5 -> "Great"
    else -> "—"
}
