package com.momentum.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.momentum.app.core.Constants
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = Constants.SETTINGS_DATASTORE)

data class SettingsData(
    val userName: String = "",
    val onboardingComplete: Boolean = false,
    val themeMode: Int = 2,
    val dynamicColor: Boolean = true,
    val remindersEnabled: Boolean = true,
    val dailyDigestEnabled: Boolean = true,
    val defaultFocusMinutes: Int = Constants.DEFAULT_FOCUS_MINUTES,
    val shortBreakMinutes: Int = Constants.DEFAULT_SHORT_BREAK,
    val longBreakMinutes: Int = Constants.DEFAULT_LONG_BREAK,
    val dailyHabitGoal: Int = 5,
    val aiCoachEnabled: Boolean = true
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val userName = stringPreferencesKey("user_name")
        val onboardingComplete = booleanPreferencesKey("onboarding_complete")
        val themeMode = intPreferencesKey("theme_mode")
        val dynamicColor = booleanPreferencesKey("dynamic_color")
        val remindersEnabled = booleanPreferencesKey("reminders_enabled")
        val dailyDigestEnabled = booleanPreferencesKey("daily_digest_enabled")
        val defaultFocusMinutes = intPreferencesKey("default_focus_minutes")
        val shortBreakMinutes = intPreferencesKey("short_break_minutes")
        val longBreakMinutes = intPreferencesKey("long_break_minutes")
        val dailyHabitGoal = intPreferencesKey("daily_habit_goal")
        val aiCoachEnabled = booleanPreferencesKey("ai_coach_enabled")
    }

    val settings: Flow<SettingsData> = context.dataStore.data.map { prefs ->
        SettingsData(
            userName = prefs[Keys.userName] ?: "",
            onboardingComplete = prefs[Keys.onboardingComplete] ?: false,
            themeMode = prefs[Keys.themeMode] ?: 2,
            dynamicColor = prefs[Keys.dynamicColor] ?: true,
            remindersEnabled = prefs[Keys.remindersEnabled] ?: true,
            dailyDigestEnabled = prefs[Keys.dailyDigestEnabled] ?: true,
            defaultFocusMinutes = prefs[Keys.defaultFocusMinutes] ?: Constants.DEFAULT_FOCUS_MINUTES,
            shortBreakMinutes = prefs[Keys.shortBreakMinutes] ?: Constants.DEFAULT_SHORT_BREAK,
            longBreakMinutes = prefs[Keys.longBreakMinutes] ?: Constants.DEFAULT_LONG_BREAK,
            dailyHabitGoal = prefs[Keys.dailyHabitGoal] ?: 5,
            aiCoachEnabled = prefs[Keys.aiCoachEnabled] ?: true
        )
    }

    suspend fun setUserName(value: String) = context.dataStore.edit { it[Keys.userName] = value }
    suspend fun setOnboardingComplete(value: Boolean) = context.dataStore.edit { it[Keys.onboardingComplete] = value }
    suspend fun setThemeMode(value: Int) = context.dataStore.edit { it[Keys.themeMode] = value }
    suspend fun setDynamicColor(value: Boolean) = context.dataStore.edit { it[Keys.dynamicColor] = value }
    suspend fun setRemindersEnabled(value: Boolean) = context.dataStore.edit { it[Keys.remindersEnabled] = value }
    suspend fun setDailyDigestEnabled(value: Boolean) = context.dataStore.edit { it[Keys.dailyDigestEnabled] = value }
    suspend fun setDefaultFocusMinutes(value: Int) = context.dataStore.edit { it[Keys.defaultFocusMinutes] = value }
    suspend fun setShortBreakMinutes(value: Int) = context.dataStore.edit { it[Keys.shortBreakMinutes] = value }
    suspend fun setLongBreakMinutes(value: Int) = context.dataStore.edit { it[Keys.longBreakMinutes] = value }
    suspend fun setDailyHabitGoal(value: Int) = context.dataStore.edit { it[Keys.dailyHabitGoal] = value }
    suspend fun setAiCoachEnabled(value: Boolean) = context.dataStore.edit { it[Keys.aiCoachEnabled] = value }
}
