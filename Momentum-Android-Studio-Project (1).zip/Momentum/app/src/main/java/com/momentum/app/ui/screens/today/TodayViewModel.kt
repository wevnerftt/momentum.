package com.momentum.app.ui.screens.today

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.HabitEntity
import com.momentum.app.data.local.entity.TaskEntity
import com.momentum.app.data.repository.FocusRepository
import com.momentum.app.data.repository.HabitRepository
import com.momentum.app.data.repository.SettingsRepository
import com.momentum.app.data.repository.TaskRepository
import com.momentum.app.domain.util.StreakCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HabitUi(
    val habit: HabitEntity,
    val completed: Boolean,
    val value: Int
) {
    val progressFraction: Float?
        get() = habit.targetQuantity?.takeIf { it > 1 }?.let { value.toFloat() / it.toFloat() }
}

data class TodayUiState(
    val userName: String = "",
    val greeting: String = "",
    val completionPercentage: Float = 0f,
    val currentStreak: Int = 0,
    val habits: List<HabitUi> = emptyList(),
    val tasks: List<TaskEntity> = emptyList(),
    val overdueTasks: List<TaskEntity> = emptyList(),
    val focusMinutesToday: Int = 0,
    val aiTip: String = "",
    val dailyGoal: Int = 5
) {
    val hasAnything: Boolean
        get() = habits.isNotEmpty() || tasks.isNotEmpty() || overdueTasks.isNotEmpty()
}

private data class Core(
    val habits: List<HabitEntity>,
    val logs: List<com.momentum.app.data.local.entity.HabitLogEntity>,
    val tasks: List<TaskEntity>,
    val overdue: List<TaskEntity>,
    val userName: String,
    val dailyGoal: Int
)

@HiltViewModel
class TodayViewModel @Inject constructor(
    private val habitRepository: HabitRepository,
    private val taskRepository: TaskRepository,
    private val focusRepository: FocusRepository,
    settingsRepository: SettingsRepository
) : ViewModel() {

    private val today = DateUtils.todayEpochDay()

    private val core = combine(
        habitRepository.observeActiveHabits(),
        habitRepository.observeLogsForDay(today),
        taskRepository.observeToday(),
        taskRepository.observeOverdue(),
        settingsRepository.settings
    ) { habits, logs, tasks, overdue, settings ->
        Core(
            habits = habits,
            logs = logs,
            tasks = tasks,
            overdue = overdue,
            userName = settings.userName,
            dailyGoal = settings.dailyHabitGoal
        )
    }

    private val withStreak = core.combine(habitRepository.observeCompletedEpochDays()) { c, days ->
        c to days
    }

    private val withFocus = withStreak.combine(
        focusRepository.observeMinutesBetween(
            DateUtils.startOfDayMillis(today),
            DateUtils.endOfDayMillis(today)
        )
    ) { pair, minutes -> pair to minutes }

    val state: StateFlow<TodayUiState> = withFocus
        .combine(habitRepository.observeCompletedCount(today)) { (pair, minutes), _ ->
            val (c, days) = pair
            buildState(c, days, minutes)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TodayUiState(greeting = DateUtils.greeting()))

    private fun buildState(core: Core, completedDays: Set<Long>, focusMinutes: Int): TodayUiState {
        val weekday = DateUtils.isoWeekday(today)
        val scheduled = core.habits.filter { it.scheduledOn(weekday) }
        val completedIds = core.logs.filter { it.completed }.map { it.habitId }.toSet()

        val habitUi = scheduled.map { habit ->
            val log = core.logs.firstOrNull { it.habitId == habit.id }
            HabitUi(habit = habit, completed = log?.completed == true, value = log?.value ?: 0)
        }

        val percentage = if (scheduled.isEmpty()) 0f
        else completedIds.count { id -> scheduled.any { it.id == id } }.toFloat() / scheduled.size

        val streak = StreakCalculator.currentStreak(completedDays)

        return TodayUiState(
            userName = core.userName,
            greeting = DateUtils.greeting(),
            completionPercentage = percentage,
            currentStreak = streak,
            habits = habitUi,
            tasks = core.tasks,
            overdueTasks = core.overdue,
            focusMinutesToday = focusMinutes,
            aiTip = buildTip(percentage, core, focusMinutes, streak),
            dailyGoal = core.dailyGoal
        )
    }

    private fun buildTip(percentage: Float, core: Core, focusMinutes: Int, streak: Int): String {
        return when {
            core.overdue.isNotEmpty() ->
                "You have ${core.overdue.size} overdue task(s). Clear the oldest one first to rebuild momentum."
            percentage >= 1f && streak >= 3 ->
                "Perfect day, $streak days running. Protect this streak — pick tomorrow's hardest habit now."
            percentage >= 1f ->
                "All habits done. Bank the win with a short focus block while your energy is high."
            percentage in 0.5f..0.99f ->
                "You are ${(percentage * 100).toInt()}% through today. One more habit tips the day in your favour."
            focusMinutes >= 50 && percentage < 0.5f ->
                "Strong focus today ($focusMinutes min). Balance it with a quick habit to keep your routine intact."
            streak == 0 && core.habits.isNotEmpty() ->
                "Start a fresh streak — complete one habit right now, however small."
            else ->
                "Small, consistent steps compound. Begin with a single two-minute action."
        }
    }

    fun toggleHabit(habitId: Long) {
        viewModelScope.launch {
            val habit = habitRepository.getHabit(habitId) ?: return@launch
            habitRepository.toggleHabit(habit, today)
        }
    }

    fun completeTask(taskId: Long) {
        viewModelScope.launch { taskRepository.toggleCompleted(taskId) }
    }
}
