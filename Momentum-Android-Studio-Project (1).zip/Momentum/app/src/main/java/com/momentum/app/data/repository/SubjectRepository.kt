package com.momentum.app.data.repository

import com.momentum.app.data.local.dao.SubjectDao
import com.momentum.app.data.local.entity.SubjectEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SubjectRepository @Inject constructor(
    private val subjectDao: SubjectDao
) {
    fun observeAll(): Flow<List<SubjectEntity>> = subjectDao.observeAll()
    fun observeById(id: Long): Flow<SubjectEntity?> = subjectDao.observeById(id)

    suspend fun upsert(subject: SubjectEntity): Long =
        if (subject.id == 0L) subjectDao.insert(subject) else { subjectDao.update(subject); subject.id }

    suspend fun delete(subject: SubjectEntity) = subjectDao.delete(subject)
}
