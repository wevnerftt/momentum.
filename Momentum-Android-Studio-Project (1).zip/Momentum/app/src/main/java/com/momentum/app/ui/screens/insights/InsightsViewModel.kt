package com.momentum.app.ui.screens.insights

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.repository.FocusRepository
import com.momentum.app.data.repository.HabitRepository
import com.momentum.app.data.repository.JournalRepository
import com.momentum.app.data.repository.TaskRepository
import com.momentum.app.domain.util.StreakCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class DayPoint(val epochDay: Long, val value: Float)

data class InsightsUiState(
    val weekDays: List<Long> = emptyList(),
    val focusByDay: List<DayPoint> = emptyList(),
    val habitsByDay: List<DayPoint> = emptyList(),
    val totalFocusMinutes: Int = 0,
    val focusMinutesThisWeek: Int = 0,
    val tasksCompletedThisWeek: Int = 0,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val averageMood: Float = 0f,
    val insights: List<String> = emptyList()
)

@HiltViewModel
class InsightsViewModel @Inject constructor(
    habitRepository: HabitRepository,
    focusRepository: FocusRepository,
    taskRepository: TaskRepository,
    journalRepository: JournalRepository
) : ViewModel() {

    private val weekDays = DateUtils.lastEpochDays(7)
    private val rangeStart = DateUtils.startOfDayMillis(weekDays.first())
    private val rangeEnd = DateUtils.endOfDayMillis(weekDays.last())

    private val focusFlow = focusRepository.observeBetween(rangeStart, rangeEnd)
    private val habitLogsFlow = habitRepository.observeLogsBetween(weekDays.first(), weekDays.last())
    private val habitsFlow = habitRepository.observeActiveHabits()

    private val base = combine(
        focusFlow,
        habitLogsFlow,
        habitsFlow,
        taskRepository.observeCompletedBetween(rangeStart, rangeEnd)
    ) { sessions, logs, habits, tasksDone ->
        BaseData(sessions, logs, habits, tasksDone)
    }

    private val withMood = base.combine(journalRepository.observeAverageMood()) { b, mood -> b to mood }
    private val withTotal = withMood.combine(focusRepository.observeTotalMinutes()) { (b, mood), total ->
        Triple(b, mood, total)
    }
    private val withDays = withTotal.combine(habitRepository.observeCompletedEpochDays()) { (b, mood, total), days ->
        Quad(b, mood, total, days)
    }

    val state: StateFlow<InsightsUiState> = withDays
        .combine(taskRepository.observeOpenCount()) { quad, _ ->
            build(quad)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), InsightsUiState(weekDays = weekDays))

    private data class BaseData(
        val sessions: List<com.momentum.app.data.local.entity.FocusSessionEntity>,
        val logs: List<com.momentum.app.data.local.entity.HabitLogEntity>,
        val habits: List<com.momentum.app.data.local.entity.HabitEntity>,
        val tasksCompleted: Int
    )
    private data class Quad(
        val base: BaseData,
        val mood: Float?,
        val totalFocus: Int,
        val completedDays: Set<Long>
    )

    private fun build(quad: Quad): InsightsUiState {
        val b = quad.base
        val focusByDay = weekDays.map { day ->
            val minutes = b.sessions
                .filter { DateUtils.epochDayOf(it.startedAt) == day && it.completed }
                .sumOf { it.durationMinutes }
            DayPoint(day, minutes.toFloat())
        }

        val habitsByDay = weekDays.map { day ->
            val weekday = DateUtils.isoWeekday(day)
            val scheduled = b.habits.filter { it.scheduledOn(weekday) }
            val done = b.logs.filter { it.epochDay == day && it.completed }.map { it.habitId }.toSet()
            val ratio = if (scheduled.isEmpty()) 0f
            else scheduled.count { done.contains(it.id) }.toFloat() / scheduled.size
            DayPoint(day, ratio)
        }

        val focusThisWeek = focusByDay.sumOf { it.value.toInt() }
        val streak = StreakCalculator.currentStreak(quad.completedDays)
        val longest = StreakCalculator.longestStreak(quad.completedDays)

        val bestFocusDay = focusByDay.maxByOrNull { it.value }
        val avgHabit = if (habitsByDay.isEmpty()) 0f else habitsByDay.map { it.value }.average().toFloat()

        val insights = buildInsights(
            avgHabit = avgHabit,
            focusThisWeek = focusThisWeek,
            streak = streak,
            bestFocusDay = bestFocusDay,
            tasksCompleted = b.tasksCompleted,
            mood = quad.mood
        )

        return InsightsUiState(
            weekDays = weekDays,
            focusByDay = focusByDay,
            habitsByDay = habitsByDay,
            totalFocusMinutes = quad.totalFocus,
            focusMinutesThisWeek = focusThisWeek,
            tasksCompletedThisWeek = b.tasksCompleted,
            currentStreak = streak,
            longestStreak = longest,
            averageMood = quad.mood ?: 0f,
            insights = insights
        )
    }

    private fun buildInsights(
        avgHabit: Float,
        focusThisWeek: Int,
        streak: Int,
        bestFocusDay: DayPoint?,
        tasksCompleted: Int,
        mood: Float?
    ): List<String> {
        val list = mutableListOf<String>()
        when {
            avgHabit >= 0.8f -> list.add("Habit consistency is excellent this week — keep the routine protected.")
            avgHabit >= 0.5f -> list.add("Habit consistency is solid. Push one weak day above 70% to lock in the trend.")
            avgHabit > 0f -> list.add("Habit consistency is still forming. Aim to complete at least half of each day's habits.")
            else -> list.add("No habit activity logged this week. Start with a single easy habit.")
        }

        if (focusThisWeek >= 300) list.add("You focused ${focusThisWeek} minutes this week — that is deep-work territory.")
        else if (focusThisWeek > 0) list.add("You focused ${focusThisWeek} minutes this week. Two more sessions would beat last week.")

        bestFocusDay?.let { day ->
            if (day.value > 0f) {
                list.add("Your strongest focus day was ${DateUtils.formatEpochDayShort(day.epochDay)} (${day.value.toInt()} min).")
            }
        }

        if (streak >= 3) list.add("A $streak-day streak shows real momentum. Protect it tomorrow.")
        if (tasksCompleted >= 10) list.add("You completed $tasksCompleted tasks this week — strong execution.")
        if (mood > 0f) list.add("Your average journal mood is ${"%.1f".format(mood)}/5.")

        return list
    }
}
