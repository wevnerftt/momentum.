package com.momentum.app.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.momentum.app.core.Constants
import com.momentum.app.core.util.DateUtils
import com.momentum.app.data.local.entity.HabitEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun scheduleHabitReminder(habit: HabitEntity) {
        val time = DateUtils.parseTimeOrNull(habit.reminderTime) ?: return
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val pending = pendingIntent(habit.id, habit.name)
        val triggerAt = nextTriggerMillis(time)

        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else true

        runCatching {
            if (canExact) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
            }
        }.onFailure {
            runCatching { alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pending) }
        }
    }

    fun cancelHabitReminder(habitId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pending = pendingIntent(habitId, null)
        runCatching { alarmManager.cancel(pending) }
    }

    fun rescheduleAll(habits: List<HabitEntity>) {
        habits.forEach { habit ->
            if (!habit.reminderTime.isNullOrBlank()) scheduleHabitReminder(habit)
        }
    }

    fun ensureDailyDigestScheduled() {
        val request = PeriodicWorkRequestBuilder<DailyDigestWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(millisUntil(8, 0), TimeUnit.MILLISECONDS)
            .addTag(Constants.DAILY_DIGEST_WORK)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            Constants.DAILY_DIGEST_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun pendingIntent(habitId: Long, habitName: String?): PendingIntent {
        val intent = Intent(context, HabitAlarmReceiver::class.java).apply {
            action = HabitAlarmReceiver.ACTION_HABIT_REMINDER
            putExtra(HabitAlarmReceiver.EXTRA_HABIT_ID, habitId)
            if (habitName != null) putExtra(HabitAlarmReceiver.EXTRA_HABIT_NAME, habitName)
        }
        return PendingIntent.getBroadcast(
            context,
            habitId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun nextTriggerMillis(time: LocalTime): Long {
        val zone = ZoneId.systemDefault()
        var target = LocalDateTime.of(LocalDate.now(zone), time)
        if (target.atZone(zone).toInstant().toEpochMilli() <= System.currentTimeMillis()) {
            target = target.plusDays(1)
        }
        return target.atZone(zone).toInstant().toEpochMilli()
    }

    private fun millisUntil(hour: Int, minute: Int): Long {
        val now = System.currentTimeMillis()
        val target = nextTriggerMillis(LocalTime.of(hour, minute))
        return (target - now).coerceAtLeast(0)
    }
}
