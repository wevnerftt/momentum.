package com.momentum.app.core.util

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

object DateUtils {

    private val zone: ZoneId get() = ZoneId.systemDefault()

    fun todayEpochDay(): Long = LocalDate.now(zone).toEpochDay()

    fun epochDayOf(millis: Long): Long =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate().toEpochDay()

    fun startOfDayMillis(epochDay: Long): Long =
        LocalDate.ofEpochDay(epochDay).atStartOfDay(zone).toInstant().toEpochMilli()

    fun startOfTodayMillis(): Long = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()

    fun endOfDayMillis(epochDay: Long): Long =
        LocalDate.ofEpochDay(epochDay).plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() - 1

    fun millisOf(date: LocalDate): Long = date.atStartOfDay(zone).toInstant().toEpochMilli()

    fun toLocalDate(millis: Long): LocalDate = Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()

    fun daysBetween(fromEpochDay: Long, toEpochDay: Long): Long =
        toEpochDay - fromEpochDay

    fun isOverdue(dueMillis: Long?): Boolean {
        if (dueMillis == null) return false
        return dueMillis < startOfTodayMillis()
    }

    fun isToday(dueMillis: Long?): Boolean {
        if (dueMillis == null) return false
        return epochDayOf(dueMillis) == todayEpochDay()
    }

    /** ISO weekday, Monday = 1 ... Sunday = 7. */
    fun isoWeekday(epochDay: Long): Int =
        LocalDate.ofEpochDay(epochDay).dayOfWeek.value

    /** Last [count] epoch-days ending today, oldest first. */
    fun lastEpochDays(count: Int): List<Long> {
        val today = todayEpochDay()
        return (count - 1 downTo 0).map { today - it }
    }

    fun parseTimeOrNull(hhmm: String?): LocalTime? = try {
        if (hhmm.isNullOrBlank()) null else LocalTime.parse(hhmm, DateTimeFormatter.ofPattern("HH:mm"))
    } catch (e: Exception) {
        null
    }

    fun formatEpochDayShort(epochDay: Long): String {
        val d = LocalDate.ofEpochDay(epochDay)
        return d.format(DateTimeFormatter.ofPattern("EEE"))
    }

    fun formatDateFull(millis: Long?): String {
        if (millis == null) return "No date"
        return toLocalDate(millis).format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
    }

    fun formatTime(millis: Long): String {
        return Instant.ofEpochMilli(millis).atZone(zone)
            .format(DateTimeFormatter.ofPattern("hh:mm a"))
    }

    fun greeting(): String {
        val hour = LocalTime.now(zone).hour
        return when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            hour < 21 -> "Good evening"
            else -> "Good night"
        }
    }
}
