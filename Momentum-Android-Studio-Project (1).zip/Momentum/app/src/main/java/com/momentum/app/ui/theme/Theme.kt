package com.momentum.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColors = darkColorScheme(
    primary = EmeraldGreen,
    onPrimary = Color(0xFF04231A),
    primaryContainer = EmeraldDark,
    onPrimaryContainer = Color(0xFFDCFCE7),
    secondary = IndigoAccent,
    onSecondary = Color.White,
    tertiary = AmberAccent,
    background = DeepObsidian,
    onBackground = LiquidWhite,
    surface = SoftSlate,
    onSurface = LiquidWhite,
    surfaceVariant = Slate700,
    onSurfaceVariant = CloudGray,
    outline = Color(0xFF475569),
    error = RoseAccent
)

private val LightColors = lightColorScheme(
    primary = EmeraldDark,
    onPrimary = Color.White,
    primaryContainer = EmeraldLight,
    onPrimaryContainer = Color(0xFF052E1B),
    secondary = IndigoAccent,
    onSecondary = Color.White,
    tertiary = AmberAccent,
    background = LiquidWhite,
    onBackground = DeepObsidian,
    surface = Color.White,
    onSurface = DeepObsidian,
    surfaceVariant = Color(0xFFEEF2F7),
    onSurfaceVariant = Slate700,
    outline = Color(0xFFCBD5E1),
    error = RoseAccent
)

@Composable
fun MomentumTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MomentumTypography,
        shapes = MomentumShapes,
        content = content
    )
}
