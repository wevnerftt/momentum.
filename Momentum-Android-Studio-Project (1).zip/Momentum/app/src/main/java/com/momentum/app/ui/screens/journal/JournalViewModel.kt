package com.momentum.app.ui.screens.journal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.data.local.entity.JournalEntity
import com.momentum.app.data.repository.JournalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class JournalUiState(
    val entries: List<JournalEntity> = emptyList(),
    val query: String = ""
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class JournalViewModel @Inject constructor(
    private val journalRepository: JournalRepository
) : ViewModel() {

    private val query = MutableStateFlow("")

    val state: StateFlow<JournalUiState> = query
        .flatMapLatest { q ->
            if (q.isBlank()) journalRepository.observeAll()
            else journalRepository.search(q)
        }
        .let { entriesFlow ->
            kotlinx.coroutines.flow.combine(entriesFlow, query) { entries, q ->
                JournalUiState(entries = entries, query = q)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), JournalUiState())

    fun setQuery(value: String) { query.value = value }

    fun delete(entry: JournalEntity) {
        viewModelScope.launch { journalRepository.delete(entry) }
    }
}
