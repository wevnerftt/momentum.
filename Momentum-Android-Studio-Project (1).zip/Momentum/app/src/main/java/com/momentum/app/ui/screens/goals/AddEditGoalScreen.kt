@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.momentum.app.ui.screens.goals

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.core.Constants
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumPrimaryButton
import com.momentum.app.ui.components.MomentumTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditGoalScreen(
    onDone: () -> Unit,
    viewModel: AddEditGoalViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.saved) { if (state.saved) onDone() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEditing) "Edit goal" else "New goal") },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (state.isEditing) {
                        IconButton(onClick = viewModel::delete) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MomentumCard {
                Column {
                    MomentumTextField(
                        value = state.title,
                        onValueChange = viewModel::setTitle,
                        label = "Goal title",
                        placeholder = "e.g. Learn Android development"
                    )
                    Spacer(Modifier.height(12.dp))
                    MomentumTextField(
                        value = state.description,
                        onValueChange = viewModel::setDescription,
                        label = "Why this matters (optional)",
                        singleLine = false,
                        minLines = 3
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Category", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Constants.GOAL_CATEGORIES.forEach { category ->
                            FilterChip(
                                selected = state.category == category,
                                onClick = { viewModel.setCategory(category) },
                                label = { Text(category.lowercase().replaceFirstChar { it.uppercase() }) }
                            )
                        }
                    }
                }
            }

            MomentumCard {
                Column {
                    Text("Target date", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = state.targetDate == null,
                            onClick = { viewModel.setTargetInDays(null) },
                            label = { Text("None") }
                        )
                        listOf(7L to "1 week", 30L to "1 month", 90L to "3 months", 180L to "6 months")
                            .forEach { (days, label) ->
                                val target = com.momentum.app.core.util.DateUtils
                                    .millisOf(java.time.LocalDate.now().plusDays(days))
                                FilterChip(
                                    selected = state.targetDate == target,
                                    onClick = { viewModel.setTargetInDays(days) },
                                    label = { Text(label) }
                                )
                            }
                    }
                }
            }

            MomentumCard {
                Column {
                    Text(
                        "Progress: ${(state.progress * 100).toInt()}%",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Slider(
                        value = state.progress,
                        onValueChange = viewModel::setProgress,
                        valueRange = 0f..1f
                    )
                }
            }

            MomentumPrimaryButton(
                text = "Save goal",
                onClick = viewModel::save,
                enabled = state.isValid,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
