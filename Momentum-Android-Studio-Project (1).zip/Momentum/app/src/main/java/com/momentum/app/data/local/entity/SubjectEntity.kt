package com.momentum.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "subjects")
@Serializable
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorHex: String = "#6366F1",
    val examDate: Long? = null,
    val targetHours: Int = 10,
    val difficulty: Int = 2, // 1 easy .. 3 hard
    val goalId: Long? = null
)
