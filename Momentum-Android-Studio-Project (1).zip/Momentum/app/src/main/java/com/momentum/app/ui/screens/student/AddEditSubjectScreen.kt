@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.momentum.app.ui.screens.student

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.app.ui.components.MomentumCard
import com.momentum.app.ui.components.MomentumPrimaryButton
import com.momentum.app.ui.components.MomentumTextField
import com.momentum.app.ui.theme.AccentPalette
import com.momentum.app.ui.theme.toHex

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditSubjectScreen(
    onDone: () -> Unit,
    viewModel: AddEditSubjectViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.saved) { if (state.saved) onDone() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEditing) "Edit subject" else "New subject") },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (state.isEditing) {
                        IconButton(onClick = viewModel::delete) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MomentumCard {
                Column {
                    MomentumTextField(
                        value = state.name,
                        onValueChange = viewModel::setName,
                        label = "Subject name",
                        placeholder = "e.g. Data Structures"
                    )
                    Spacer(Modifier.height(12.dp))
                    MomentumTextField(
                        value = state.targetHours,
                        onValueChange = viewModel::setTargetHours,
                        label = "Target study hours",
                        keyboardType = KeyboardType.Number
                    )
                }
            }

            MomentumCard {
                Column {
                    Text("Difficulty", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1 to "Easy", 2 to "Medium", 3 to "Hard").forEach { (value, label) ->
                            FilterChip(
                                selected = state.difficulty == value,
                                onClick = { viewModel.setDifficulty(value) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            MomentumCard {
                Column {
                    Text("Exam date", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = state.examDate == null,
                            onClick = { viewModel.setExamInDays(null) },
                            label = { Text("None") }
                        )
                        listOf(3L to "In 3 days", 7L to "1 week", 14L to "2 weeks", 30L to "1 month")
                            .forEach { (days, label) ->
                                val target = com.momentum.app.core.util.DateUtils
                                    .millisOf(java.time.LocalDate.now().plusDays(days))
                                FilterChip(
                                    selected = state.examDate == target,
                                    onClick = { viewModel.setExamInDays(days) },
                                    label = { Text(label) }
                                )
                            }
                    }
                }
            }

            MomentumCard {
                Column {
                    Text("Colour", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AccentPalette.forEach { color ->
                            val selected = state.colorHex.equals(color.toHex(), ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (selected) 3.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        shape = CircleShape
                                    )
                                    .clickable { viewModel.setColor(color.toHex()) }
                            )
                        }
                    }
                }
            }

            MomentumPrimaryButton(
                text = "Save subject",
                onClick = viewModel::save,
                enabled = state.isValid,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
