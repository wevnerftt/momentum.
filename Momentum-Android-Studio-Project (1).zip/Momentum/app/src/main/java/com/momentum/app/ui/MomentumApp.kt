package com.momentum.app.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.momentum.app.ui.navigation.Routes
import com.momentum.app.ui.navigation.bottomNavItems
import com.momentum.app.ui.navigation.bottomRoutes
import com.momentum.app.ui.screens.focus.FocusScreen
import com.momentum.app.ui.screens.goals.AddEditGoalScreen
import com.momentum.app.ui.screens.goals.GoalsScreen
import com.momentum.app.ui.screens.habits.AddEditHabitScreen
import com.momentum.app.ui.screens.habits.HabitsScreen
import com.momentum.app.ui.screens.insights.InsightsScreen
import com.momentum.app.ui.screens.journal.AddEditJournalScreen
import com.momentum.app.ui.screens.journal.JournalScreen
import com.momentum.app.ui.screens.onboarding.OnboardingScreen
import com.momentum.app.ui.screens.settings.SettingsScreen
import com.momentum.app.ui.screens.student.AddEditSubjectScreen
import com.momentum.app.ui.screens.student.StudentModeScreen
import com.momentum.app.ui.screens.tasks.AddEditTaskScreen
import com.momentum.app.ui.screens.tasks.TasksScreen
import com.momentum.app.ui.screens.today.TodayScreen

@Composable
fun MomentumApp(onboardingComplete: Boolean) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = currentRoute != null && bottomRoutes.any { currentRoute.startsWith(it) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                MomentumBottomBar(navController)
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = if (onboardingComplete) Routes.TODAY else Routes.ONBOARDING,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.ONBOARDING) {
                OnboardingScreen(onFinished = {
                    navController.navigate(Routes.TODAY) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                })
            }
            composable(Routes.TODAY) {
                TodayScreen(
                    onOpenHabits = { navController.navigate(Routes.HABITS) },
                    onOpenTasks = { navController.navigate(Routes.TASKS) },
                    onOpenFocus = { navController.navigate(Routes.FOCUS) },
                    onAddTask = { navController.navigate(Routes.taskEdit()) },
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) }
                )
            }
            composable(Routes.HABITS) {
                HabitsScreen(
                    onAddHabit = { navController.navigate(Routes.habitEdit()) },
                    onEditHabit = { id -> navController.navigate(Routes.habitEdit(id)) }
                )
            }
            composable(Routes.TASKS) {
                TasksScreen(
                    onAddTask = { navController.navigate(Routes.taskEdit()) },
                    onEditTask = { id -> navController.navigate(Routes.taskEdit(id)) }
                )
            }
            composable(Routes.FOCUS) { FocusScreen() }
            composable(Routes.INSIGHTS) {
                InsightsScreen(
                    onOpenGoals = { navController.navigate(Routes.GOALS) },
                    onOpenStudent = { navController.navigate(Routes.STUDENT) },
                    onOpenJournal = { navController.navigate(Routes.JOURNAL) }
                )
            }
            composable(Routes.GOALS) {
                GoalsScreen(
                    onAddGoal = { navController.navigate(Routes.goalEdit()) },
                    onEditGoal = { id -> navController.navigate(Routes.goalEdit(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.STUDENT) {
                StudentModeScreen(
                    onAddSubject = { navController.navigate(Routes.subjectEdit()) },
                    onEditSubject = { id -> navController.navigate(Routes.subjectEdit(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.JOURNAL) {
                JournalScreen(
                    onAddEntry = { navController.navigate(Routes.journalEdit()) },
                    onEditEntry = { id -> navController.navigate(Routes.journalEdit(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }

            composable(
                route = "${Routes.HABIT_EDIT}?habitId={habitId}",
                arguments = listOf(navArgument("habitId") { type = NavType.LongType; defaultValue = -1L })
            ) {
                AddEditHabitScreen(onDone = { navController.popBackStack() })
            }
            composable(
                route = "${Routes.TASK_EDIT}?taskId={taskId}",
                arguments = listOf(navArgument("taskId") { type = NavType.LongType; defaultValue = -1L })
            ) {
                AddEditTaskScreen(onDone = { navController.popBackStack() })
            }
            composable(
                route = "${Routes.GOAL_EDIT}?goalId={goalId}",
                arguments = listOf(navArgument("goalId") { type = NavType.LongType; defaultValue = -1L })
            ) {
                AddEditGoalScreen(onDone = { navController.popBackStack() })
            }
            composable(
                route = "${Routes.SUBJECT_EDIT}?subjectId={subjectId}",
                arguments = listOf(navArgument("subjectId") { type = NavType.LongType; defaultValue = -1L })
            ) {
                AddEditSubjectScreen(onDone = { navController.popBackStack() })
            }
            composable(
                route = "${Routes.JOURNAL_EDIT}?entryId={entryId}",
                arguments = listOf(navArgument("entryId") { type = NavType.LongType; defaultValue = -1L })
            ) {
                AddEditJournalScreen(onDone = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun MomentumBottomBar(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        tonalElevation = 8.dp
    ) {
        bottomNavItems.forEach { item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.title) },
                label = { Text(item.title, style = MaterialTheme.typography.labelSmall) },
                selected = currentRoute?.startsWith(item.route) == true,
                onClick = {
                    if (currentRoute?.startsWith(item.route) != true) {
                        navController.navigate(item.route) {
                            popUpTo(Routes.TODAY) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                )
            )
        }
    }
}
