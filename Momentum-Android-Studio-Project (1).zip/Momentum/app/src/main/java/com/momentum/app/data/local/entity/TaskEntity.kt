package com.momentum.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import com.momentum.app.core.Constants

@Entity(tableName = "tasks")
@Serializable
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String? = null,
    val dueDate: Long? = null,
    val priority: Int = Constants.PRIORITY_MEDIUM,
    val isCompleted: Boolean = false,
    val goalId: Long? = null,
    val categoryId: Long? = null,
    val subjectId: Long? = null,
    val estimatedMinutes: Int? = null,
    val recurrenceRule: String? = null,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
