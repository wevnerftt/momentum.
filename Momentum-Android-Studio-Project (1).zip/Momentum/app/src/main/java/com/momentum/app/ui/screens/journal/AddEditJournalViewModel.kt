package com.momentum.app.ui.screens.journal

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.data.local.entity.JournalEntity
import com.momentum.app.data.repository.JournalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class JournalFormState(
    val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val mood: Int = 0,
    val isEditing: Boolean = false,
    val saved: Boolean = false
) {
    val isValid: Boolean get() = title.isNotBlank() && content.isNotBlank()
}

@HiltViewModel
class AddEditJournalViewModel @Inject constructor(
    private val journalRepository: JournalRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val entryId: Long = savedStateHandle.get<Long>("entryId") ?: -1L

    private val _state = MutableStateFlow(JournalFormState())
    val state: StateFlow<JournalFormState> = _state.asStateFlow()

    init { if (entryId > 0) load(entryId) }

    private fun load(id: Long) {
        viewModelScope.launch {
            val entry = journalRepository.observeById(id).first() ?: return@launch
            _state.update {
                JournalFormState(
                    id = entry.id,
                    title = entry.title,
                    content = entry.content,
                    mood = entry.mood,
                    isEditing = true
                )
            }
        }
    }

    fun setTitle(v: String) = _state.update { it.copy(title = v) }
    fun setContent(v: String) = _state.update { it.copy(content = v) }
    fun setMood(v: Int) = _state.update { it.copy(mood = if (it.mood == v) 0 else v) }

    fun save() {
        val s = _state.value
        if (!s.isValid) return
        viewModelScope.launch {
            journalRepository.upsert(
                JournalEntity(
                    id = s.id,
                    title = s.title.trim(),
                    content = s.content.trim(),
                    mood = s.mood
                )
            )
            _state.update { it.copy(saved = true) }
        }
    }

    fun delete() {
        val id = _state.value.id
        if (id <= 0) return
        viewModelScope.launch {
            journalRepository.observeById(id).first()?.let { journalRepository.delete(it) }
            _state.update { it.copy(saved = true) }
        }
    }
}
