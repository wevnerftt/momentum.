# Room
-keep class * extends androidx.room.RoomDatabase { <init>(); }
-keep @androidx.room.Entity class * { *; }
-dontwarn androidx.room.paging.**

# Hilt / Dagger
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class **$$serializer { *; }
-keepclasseswithmembers class * { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.momentum.app.**$$serializer { *; }
-keepclassmembers class com.momentum.app.** { *** Companion; }
-keepclasseswithmembers class com.momentum.app.** { kotlinx.serialization.KSerializer serializer(...); }

# WorkManager
-keep class * extends androidx.work.ListenableWorker { public <init>(...); }
